########################################################################################
## @description: Example script to execute adhoc PowerShell scripts via Ansible
## @pre: receive following parameters:
##          [string]$var1,
##          [string]$var2,
##          [int]$var3,
##
## @pos: The PowerShell script will generate a fourth variable $var4 (no input var)
##       Log will be locally visible at c:\opt\axa\factory\install\axa_sql\20_adhoc_exec
##        
## @author: nele.guilluy@axa.com
## 
########################################################################################

Param(
    [Parameter(Mandatory = $True)][string]$var1,
    [Parameter(Mandatory = $True)][string]$var2,
    [Parameter(Mandatory = $true)][int]$var3
)

## Set Log folder and log file

$outputFolder="c:\opt\axa\factory\install\axa_sql\20_adhoc_exec"
$LogFile = "adhoc_ps_exec.log"
$logpath = $outputFolder+"\"+$LogFile

If(!(test-path $outputFolder)) {New-Item -ItemType Directory -Force -Path $outputFolder}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"###### Start executing Demo PowerShell code"
Add-Content $logpath -Value $outstring


## Output the variables
$outstring = "The content of variable 1 is: $var1"
Add-Content $logpath -Value $outstring
$outstring = "The content of variable 2 is: $var2"
Add-Content $logpath -Value $outstring
$outstring = "The content of variable 3 is: $var3"
Add-Content $logpath -Value $outstring

## Read the services running on the server and output to an additional variable $var4
$var4 = Get-Service | Where-Object { $_.Name -like "*SQLSERVER*" } | Select-Object -ExpandProperty Name
$var4 # To output via the .yaml file to the Ansible console
$outstring = "The content of variable 1 is: $var4"
Add-Content $logpath -Value $outstring
