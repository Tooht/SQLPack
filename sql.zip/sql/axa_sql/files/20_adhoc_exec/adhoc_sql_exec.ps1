########################################################################################
## @description: Example script to execute adhoc SQL code via Ansible
## @pre: -
##
## @pos: -
##        
## @author: nele.guilluy@axa.com
## 
########################################################################################

##################################
## Param definition
##################################
Param(
    [Parameter(Mandatory = $True)][string]$sql_user,
    [Parameter(Mandatory = $True)][string]$sql_password
)

##################################
## Set Log folder and log file
##################################
$outputFolder="c:\opt\axa\factory\install\axa_sql\20_adhoc_exec"
$LogFile = "adhoc_sql_exec.log"
$logpath = $outputFolder+"\"+$LogFile

If(!(test-path $outputFolder)) {New-Item -ItemType Directory -Force -Path $outputFolder}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"###### Start executing Demo PowerShell code"
Add-Content $logpath -Value $outstring


##################################
## CyberArk Ansible authentication
##################################
$domain = ((Get-WmiObject Win32_ComputerSystem).Domain).Replace('.intraxa','')
$username = "$domain\$sql_user"
$password = $sql_password
$secureString = ConvertTo-SecureString $password -AsPlainText -Force
          
$cred = New-Object System.Management.Automation.PSCredential($username, $secureString)
$cred.GetNetworkCredential().UserName

$SQLQuery = "SELECT @@SERVERNAME AS SQLServerName, @@VERSION AS SQLVersion"

$SqlCmdVersion = (Get-Command -Name Invoke-sqlcmd).Version.Major
$sqlinstance = "localhost"
$OutputObject = @( @{ColA=$ArrListA; ColB=$ArrListB; ColC=$ArrListC; ColD=$ArrListD})
if($SqlCmdVersion -ge 22){
    $OutputObject = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:SQLQuery -TrustServerCertificate -QueryTimeout 0} -Credential $cred
}else{
    $OutputObject = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:SQLQuery -QueryTimeout 0} -Credential $cred
}

$SQLServerName = $OutputObject.SQLServerName
Add-Content $logpath -Value "The SQLServerName is: "
Add-Content $logpath -Value $SQLServerName
$SQLVersion = $OutputObject.SQLVersion
Add-Content $logpath -Value "The SQLVersion is: "
Add-Content $logpath -Value $SQLVersion
