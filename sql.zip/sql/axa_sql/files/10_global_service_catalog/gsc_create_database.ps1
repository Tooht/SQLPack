#######################################
## @description: Script to automate database creation
##                  check available disk space and database existance,
##                  create database if conditions are meet
## @pre: receive following paramenters:
##          [string]$sqlinstance,
##          [string]$dbname,
##          [int]$initialdatasizegb,
##          [int]$initiallogsizegb,
##
## @pos: log should be locally visible at C:\opt\axa\factory\install\sql_db_creation
##          database created on SQL Server Instance
##
## @author: daniel.carvalho@axa.com
## 
##
#######################################

Param(
    [Parameter(Mandatory = $True)][string]$sql_user,
    [Parameter(Mandatory = $True)][string]$sql_password,
    [Parameter(Mandatory = $True)][string]$sqlinstance,
    [Parameter(Mandatory = $True)][string]$dbname,
    [Parameter(Mandatory = $true)][int]$initialdatasizegb,
    [Parameter(Mandatory = $true)][int]$initiallogsizegb
)

#########################
## Db name validation
## valid chars [a-z][A-Z][0-9][_]
#########################
$dbname=$dbname.Trim()
if($dbname -match '^[a-zA-Z0-9_]+$'){

}else{
    Throw "Invalid database name"
}

##########################
## Set Log folder and log file
##########################
$outputFolder="C:\opt\axa\factory\install\sql_db_creation"
$LogFile = "01_"+$dbname+".log"
$logpath = $outputFolder+"\"+$LogFile
$SqlCmdVersion = (Get-Command -Name Invoke-sqlcmd).Version.Major

If(!(test-path $outputFolder)) {New-Item -ItemType Directory -Force -Path $outputFolder}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"###### Create database process start"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## DB name: $dbname"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## Action: Create"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## Data Size: $initialdatasizegb"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## Log Size: $initiallogsizegb"
Add-Content $logpath -Value $outstring

if($sqlinstance -eq "MSSQLSERVER"){
    $sqlinstance="localhost"
}else{
    $sqlinstance=".\"+$sqlinstance
}

##################################
## CyberArk Ansible authentication
##################################
$domain = ((Get-WmiObject Win32_ComputerSystem).Domain).Replace('.intraxa','')
$username = "$domain\$sql_user"
$password = $sql_password
$secureString = ConvertTo-SecureString $password -AsPlainText -Force
          
$cred = New-Object System.Management.Automation.PSCredential($username, $secureString)
$cred.GetNetworkCredential().UserName


#############################
## check available disk space
#############################
$q="Declare @drive varchar(2)
SELECT @drive=left(cast(SERVERPROPERTY('InstanceDefaultDataPath') as varchar(512)),( Charindex(':', cast(SERVERPROPERTY('InstanceDefaultDataPath') as varchar(512))) - 1 ))

create table #tbl (drive varchar(8), MBFree integer)
    insert into #tbl
    execute xp_fixeddrives

    select * from #tbl
	where drive=@drive"


$output_object = @( @{Col1=$ArrList1; Col2=$ArrList2; Col3=$ArrList3; Col4=$ArrList4 })
if($SqlCmdVersion -ge 22){
    $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -TrustServerCertificate -QueryTimeout 0} -Credential $cred
}else{
    $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -QueryTimeout 0} -Credential $cred
}


$outstring="| Disk `t| Free Space `t| "
Add-Content $logpath -Value $outstring
foreach($row in $output_object){
    $outstring="| "+$row.drive+" `t| "+$row.MBfree+" `t| "
    Add-Content $logpath -Value $outstring
    if($row.MBfree -lt (($initialdatasizegb+$initiallogsizegb)*1024)){
        $outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"# not enough space on disk"
        write-host $outstring
        Add-Content $logpath -Value $outstring
        $outstring="Drive "+$row.drive+":\ has "+$row.MBfree+"MB of free space "
        write-host $outstring
        Add-Content $logpath -Value $outstring
        exit 1
    }else{
        $msg="Drive "+$row.drive+":\ has "+$row.MBfree+"MB of free space "
        write-host $msg
    }
}

##########################
## generate command end execution
##########################
$q="CREATE DATABASE "+$dbname+" ON  PRIMARY 
( NAME = N'"+$dbname+"', FILENAME = N'F:\DBSQL\Data\"+$dbname+".mdf' , SIZE = "+$initialdatasizegb+"GB , FILEGROWTH = 128MB )
 LOG ON 
( NAME = N'"+$dbname+"_log', FILENAME = N'F:\DBSQL\Logs\"+$dbname+"_log.ldf' , SIZE = "+$initiallogsizegb+"GB , FILEGROWTH = 128MB )
GO
use "+$dbname+"
GO
EXEC sp_changedbowner 'sa'
GO
"

#write-host $q


$output_object = @( @{Col1=$ArrList1; Col2=$ArrList2 })
   if($SqlCmdVersion -ge 22){
       try{
           $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -TrustServerCertificate -QueryTimeout 0} -Credential $cred
           write-host "Command executed successfully"
           $outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"# Command executed successfully"
           Add-Content $logpath -Value $outstring
       }catch{
           write-host "Error executing command: "
           write-host $q
       }
   }else{
       try{
           $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -QueryTimeout 0} -Credential $cred
           write-host "Command executed successfully"
           $outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"# Command executed successfully"
           Add-Content $logpath -Value $outstring
       }catch{
           write-host "Error executing command: "
           write-host $q
       }
   }

write-host $output_object