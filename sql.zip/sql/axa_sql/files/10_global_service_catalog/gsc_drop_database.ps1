#######################################
## @description: Script to automate database drop
##                  Must be executed after sql_aiops_offline_database
##
## @pre: receive following paramenters:
##          [string]$sqlinstance,
##          [string]$dbname,
##          
## @pos: Database should not exist after execution of this code
##
## @author: daniel.carvalho@axa.com
## 
##
#######################################

Param(
    [Parameter(Mandatory = $True)][string]$sql_user,
    [Parameter(Mandatory = $True)][string]$sql_password,
    [Parameter(Mandatory = $True)][string]$sqlinstance,
    [Parameter(Mandatory = $True)][string]$dbname
)

$dbname=$dbname.Trim()
if($dbname -match '^[a-zA-Z0-9_]+$'){

}else{
    Throw "Invalid database name"
}

##########################
## Set Log folder and log file
##########################
$outputFolder="C:\opt\axa\factory\install\sql_db_creation"
$LogFile = "01_"+$dbname+".log"
$logpath = $outputFolder+"\"+$LogFile
$SqlCmdVersion = (Get-Command -Name Invoke-sqlcmd).Version.Major

If(!(test-path $outputFolder)) {New-Item -ItemType Directory -Force -Path $outputFolder}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"###### Drop database process start"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## DB name: $dbname"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## Action: Drop"
Add-Content $logpath -Value $outstring

if($sqlinstance -eq "MSSQLSERVER"){
    $sqlinstance="localhost"
}else{
    $sqlinstance=".\"+$sqlinstance
}

##################################
## CyberArk Ansible authentication
##################################
$domain = ((Get-WmiObject Win32_ComputerSystem).Domain).Replace('.intraxa','')
$username = "$domain\$sql_user"
$password = $sql_password
$secureString = ConvertTo-SecureString $password -AsPlainText -Force
          
$cred = New-Object System.Management.Automation.PSCredential($username, $secureString)
$cred.GetNetworkCredential().UserName

##################################
## Check database state
##################################

$q="select name,state_desc from sys.databases where name='"+$dbname+"'"


$output_object = @( @{Col1=$ArrList1; Col2=$ArrList2 })
if($SqlCmdVersion -ge 22){
    $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -TrustServerCertificate -QueryTimeout 0} -Credential $cred
}else{
    $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -QueryTimeout 0} -Credential $cred
}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## DB State: "+$output_object.name+" State: "+$output_object.state_desc
Add-Content $logpath -Value $outstring

##################################
## Drop database
##################################
if($output_object.state_desc -eq "offline"){
write-host $dbname
$q="EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'"+$dbname+"'
GO
ALTER DATABASE ["+$dbname+"] SET ONLINE;
ALTER DATABASE ["+$dbname+"] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO
DROP DATABASE ["+$dbname+"]
GO
"


$output_object = @( @{Col1=$ArrList1 })
if($SqlCmdVersion -ge 22){
    try{
        $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -TrustServerCertificate -QueryTimeout 0} -Credential $cred
        write-host "Database $dbname dropped!"
    }catch{
        write-host "Error executing command: "
        write-host $q
    }
}else{
    try{
        $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -QueryTimeout 0} -Credential $cred
        write-host "Database $dbname dropped!"
    }catch{
        write-host "Error executing command: "
        write-host $q
    }
}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## Drop Database Completed"
Add-Content $logpath -Value $outstring
write-host $output_object
}