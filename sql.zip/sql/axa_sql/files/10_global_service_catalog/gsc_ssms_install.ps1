#######################################
## @description: Script to automate SQL Server Management Studio Installation
##
## @pre: No parameters sent
##          
## @pos: SSMS should then be installed by choco
##
## @author: daniel.carvalho@axa.com
## 
##
#######################################
$chocoget= choco source
$iposition=$chocoget.count-1
$repository=$chocoget[$iposition].substring($chocoget[$iposition].IndexOf("//")+2,$chocoget[$iposition].IndexOf(".")-$chocoget[$iposition].IndexOf("//")-2)

$installcmd="Choco install sql-ms --PackageParameters='/GenericRepo:https://"+$repository+".wwmgmt.intraxa/artifactory/axa_gen_prod' -force -y --no-progress"
Invoke-Expression $installcmd
Write-host "SSMS installation completed!"