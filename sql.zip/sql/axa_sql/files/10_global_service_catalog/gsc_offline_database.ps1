#######################################
## @description: Script to automate database offline
##                  Change database state to offline 
##
## @pre: receive following paramenters:
##          [string]$sqlinstance,
##          [string]$dbname,
##          
## @pos: Database should remain in offline state after this script
##
## @author: daniel.carvalho@axa.com
## 
##
#######################################
Param(
    [Parameter(Mandatory = $True)][string]$sql_user,
    [Parameter(Mandatory = $True)][string]$sql_password,
    [Parameter(Mandatory = $True)][string]$sqlinstance,
    [Parameter(Mandatory = $True)][string]$dbname
)

$dbname=$dbname.Trim()
if($dbname -match '^[a-zA-Z0-9_]+$'){

}else{
    Throw "Invalid database name"
}

$outputFolder="C:\opt\axa\factory\install\sql_db_creation"
$LogFile = "01_"+$dbname+".log"
$logpath = $outputFolder+"\"+$LogFile
$SqlCmdVersion = (Get-Command -Name Invoke-sqlcmd).Version.Major

If(!(test-path $outputFolder)) {New-Item -ItemType Directory -Force -Path $outputFolder}

$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"###### Offline database process start"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## DB name: $dbname"
Add-Content $logpath -Value $outstring
$outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"## Action: Offline"
Add-Content $logpath -Value $outstring


if($sqlinstance -eq "MSSQLSERVER"){
    $sqlinstance="localhost"
}else{
    $sqlinstance=".\"+$sqlinstance
}

##################################
## CyberArk Ansible authentication
##################################
$domain = ((Get-WmiObject Win32_ComputerSystem).Domain).Replace('.intraxa','')
$username = "$domain\$sql_user"
$password = $sql_password
$secureString = ConvertTo-SecureString $password -AsPlainText -Force
          
$cred = New-Object System.Management.Automation.PSCredential($username, $secureString)
$cred.GetNetworkCredential().UserName

##################################
## Check database exists
##################################
$q="select name,state_desc from sys.databases where name='"+$dbname+"'"

$output_object = @( @{Col1=$ArrList1; Col2=$ArrList2 })
if($SqlCmdVersion -ge 22){
    $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -TrustServerCertificate -QueryTimeout 0} -Credential $cred
}else{
    $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -QueryTimeout 0} -Credential $cred
}

##################################
## Set database OFFLINE
##################################
$outstring="## DB State: "+$output_object.name+" State: "+$output_object.state_desc

$q="ALTER DATABASE "+$dbname+" SET SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
ALTER DATABASE "+$dbname+" SET OFFLINE
GO
"

write-host $q


$output_object = @( @{Col1=$ArrList1 })
if($SqlCmdVersion -ge 22){
    try{
        $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -TrustServerCertificate -QueryTimeout 0} -Credential $cred
        write-host "Command executed successfully"
        $outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"# Command executed successfully"
        Add-Content $logpath -Value $outstring
    }catch{
        write-host "Error executing command: "
        write-host $q
    }
}else{
    try{
        $output_object = Invoke-Command -ComputerName localhost -ScriptBlock {Invoke-Sqlcmd -ServerInstance $Using:sqlinstance -Query $Using:q -QueryTimeout 0} -Credential $cred
        write-host "Command executed successfully"
        $outstring=(get-date -f "yyyy/MM/dd hh:mm:ss.fff tt")+"# Command executed successfully"
        Add-Content $logpath -Value $outstring
    }catch{
        write-host "Error executing command: "
        write-host $q
    }
}

Add-Content $logpath -Value "## SET Database Offline"
write-host $output_object