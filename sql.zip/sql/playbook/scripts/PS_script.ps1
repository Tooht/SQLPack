# Define the path for the new file
$filePath = "c:\opt\axa\factory\install\sql_ansible\NewFile.txt"

# Check if the file exists
if (Test-Path -Path $filePath) {
    # Delete the existing file
    Remove-Item -Path $filePath
}
# Create the file and write "Hello AXA" into it
"Hello AXA" | Out-File -FilePath $filePath -Encoding UTF8

# Optional: Output a message to confirm the file was created
Write-Output "File created at: $filePath"