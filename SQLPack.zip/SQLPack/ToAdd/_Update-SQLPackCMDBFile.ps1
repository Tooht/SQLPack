
function Update-SQLPackCMDBFile{ 
 
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose   "[$FunctionName] Preparing to write log with message: $Message, level: $Level"

    $Query ="Declare @JobName varchar(200)
SELECT @JobName=[name] FROM msdb.dbo.sysjobs WHERE UPPER([name]) LIKE'%CMDB%LAST%'
EXEC msdb.dbo.sp_start_job @JobName
"

    Invoke-SQLIntQuery $Query

 }
 