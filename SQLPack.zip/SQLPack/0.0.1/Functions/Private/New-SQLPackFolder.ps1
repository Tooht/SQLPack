function Set-Folder {
    Param(
    [Parameter(Mandatory=$true)]
        [string]$ParentFolder,
    [Parameter(Mandatory=$true)]
        [string]$FolderName,
    [Parameter(Mandatory=$false)]
        [switch]$EmptyIfExists
    )
$ParentFolder.split("\")|ForEach-Object
{
    Write-Host $_
}
    # $R = New-Item -ItemType "Directory" -Path $FolderFullPath -Force
    # $R = Get-ChildItem -Path $FolderFullPath | Remove-Item -Force -Recurse



}