function FUNCTION-NAME {
    param (      
        [Parameter(Mandatory=$false)]
            [switch] $Param1,

        [Parameter(Mandatory=$false)]
            [int]$Param2,

        [Parameter(Mandatory=$false)]
            [ArgumentCompleter({Get-SQLPackDatabasesNames -NotFomated} )]
            [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames -NotFomated)} )]
            [string]$Param3,

        [Parameter(Mandatory=$false)]
            [ValidateSet("LastYear","LastMonth","LastWeek","LastDay")]
            [string]$Param4,

        [Parameter(Mandatory=$false)]
            [switch] $Param5
    )

    $FunctionName=(Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"
    Write-Verbose "[$FunctionName] Param1='$Param1'"
    Write-Verbose "[$FunctionName] Param2='$Param2'"
    Write-Verbose "[$FunctionName] Param3='$Param3'"
    Write-Verbose "[$FunctionName] Param4='$Param4'"
    Write-Verbose "[$FunctionName] Param5='$Param5'"





    Write-Verbose "[$FunctionName] END START"
}