﻿function Get-SQLPackDriveLatency{ 
param (
        [Parameter(Mandatory=$false)]
            [string]$InstanceName=".",

        [Parameter(Mandatory=$false)]
            [string]$InstancePort="30000",

        [Parameter(Mandatory=$false)]
            [int] $QueryTimeOut=0,

        [Parameter(Mandatory=$false)]
            [int] $MaxRecords=100,
        
        [Parameter(Mandatory=$false)]
            [ArgumentCompleter({Get-SQLPackDatabasesNames } )]
            [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames)} )]
            [string]$DatabaseName,

        [Parameter(Mandatory=$false)]
            [switch] $NotFomated,

        [Parameter(Mandatory=$false)]
            [ValidateSet("ByDriveLetter","ByDatabaseFile")]
            [string] $ListType="ByDatabaseFile"
    )
    $FunctionName=(Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] Preparing to Drive Latency with filters: ListType:'$ListType'"

if ($DatabaseName){$QueryFilter= " Where DB_NAME(fs.database_id)='$DatabaseName'"}

    switch($ListType){
    "ByDriveLetter" {$Query ="SELECT tab.[Drive], tab.volume_mount_point AS [Volume Mount Point],
	        CASE 
		        WHEN num_of_reads = 0 THEN 0 
		        ELSE (io_stall_read_ms/num_of_reads) 
	        END AS [ReadLatency],
	        CASE 
		        WHEN num_of_writes = 0 THEN 0 
		        ELSE (io_stall_write_ms/num_of_writes) 
	        END AS [WriteLatency],
	        CASE 
		        WHEN (num_of_reads = 0 AND num_of_writes = 0) THEN 0 
		        ELSE (io_stall/(num_of_reads + num_of_writes)) 
	        END AS [OverallLatency],
	        CASE 
		        WHEN num_of_reads = 0 THEN 0 
		        ELSE (num_of_bytes_read/num_of_reads) 
	        END AS [AvgBytes/Read],
	        CASE 
		        WHEN num_of_writes = 0 THEN 0 
		        ELSE (num_of_bytes_written/num_of_writes) 
	        END AS [AvgBytes/Write],
	        CASE 
		        WHEN (num_of_reads = 0 AND num_of_writes = 0) THEN 0 
		        ELSE ((num_of_bytes_read + num_of_bytes_written)/(num_of_reads + num_of_writes)) 
	        END AS [AvgBytes/Transfer]
        FROM (SELECT LEFT(UPPER(mf.physical_name), 2) AS Drive, SUM(num_of_reads) AS num_of_reads,
		        SUM(io_stall_read_ms) AS io_stall_read_ms, SUM(num_of_writes) AS num_of_writes,
		        SUM(io_stall_write_ms) AS io_stall_write_ms, SUM(num_of_bytes_read) AS num_of_bytes_read,
		        SUM(num_of_bytes_written) AS num_of_bytes_written, SUM(io_stall) AS io_stall, vs.volume_mount_point
	        FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS vfs
		        INNER JOIN sys.master_files AS mf WITH (NOLOCK)
		        ON vfs.database_id = mf.database_id AND vfs.file_id = mf.file_id
	            CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.[file_id]) AS vs
	        GROUP BY LEFT(UPPER(mf.physical_name), 2), vs.volume_mount_point) AS tab
        ORDER BY [OverallLatency]"}

    "ByDatabaseFile" {$Query="SELECT DB_NAME(fs.database_id) AS [Database Name], 
        mf.physical_name, 
        mf.type_desc, 
        CAST(fs.io_stall_read_ms/(1.0 + fs.num_of_reads) AS NUMERIC(10,1)) AS [avg_read_latency_ms],
        CAST(fs.io_stall_write_ms/(1.0 + fs.num_of_writes) AS NUMERIC(10,1)) AS [avg_write_latency_ms],
        CAST((fs.io_stall_read_ms + fs.io_stall_write_ms)/(1.0 + fs.num_of_reads + fs.num_of_writes) AS NUMERIC(10,1)) AS [avg_io_latency_ms],
        CONVERT(DECIMAL(18,2), mf.size/128.0) AS [File Size (MB)], 
        fs.num_of_reads, 
        fs.num_of_writes, 
        fs.num_of_reads + fs.num_of_writes AS [total_io],
        fs.io_stall_read_ms, 
        fs.io_stall_write_ms, 
        fs.io_stall_read_ms + fs.io_stall_write_ms AS [io_stalls]
        FROM sys.dm_io_virtual_file_stats(null,null) AS fs
        INNER JOIN sys.master_files AS mf WITH (NOLOCK)
        ON fs.database_id = mf.database_id
        AND fs.[file_id] = mf.[file_id]
        $QueryFilter
        ORDER BY 1,2"}
    }
    Write-Verbose "Query: $Query"
    $Result=Invoke-SQLIntQuery  $Query
    
    if($NotFomated){return $Result}
    else {return $Result|FT}
}
