﻿

 function Get-SQLPackBlockingSessions{ 
param (
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated
    )
   
        $Query="select session_id, D.name as DatabaseName, request_id, start_time, status, command, user_id, transaction_id, percent_complete, estimated_completion_time, total_elapsed_time
                            FROM sys.dm_exec_requests R
                                inner join sys.databases D
                                On R.database_id=D.database_id
                            WHERE session_id in ( SELECT blocking_session_id
                            FROM sys.dm_exec_requests
                            WHERE blocking_session_id <> 0 )"
    
      Return (Format-Result -Result (Invoke-SQLIntQuery -SQLQuery $Query) -NotFomated $NotFomated)

}

    