﻿

 function Get-SQLPackBlockedSessions{ 
param (
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated
    )

 

        $Query="SELECT session_id, D.name as DatabaseName, request_id, start_time, status, command, user_id, blocking_session_id, wait_type
                            FROM sys.dm_exec_requests R 
                            inner join sys.databases D 
                            On R.database_id=D.database_id 
                            WHERE blocking_session_id <> 0"
        

      return (Format-Result -Result (Invoke-SQLIntQuery -SQLQuery $Query) -NotFomated $NotFomated)

}

    