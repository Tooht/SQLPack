function Set-SQLPackConfigUserFile {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $Force 
    )
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"


    $Folder = (get-item $PSScriptRoot )
    Write-Verbose "[$FunctionName] Current folder: $Folder"

    Do {
        $Folder = (get-item $Folder.FullName ).parent
    } While ($Folder.Name -ne "SQLPack") 
    $Folder = (Get-ChildItem -Path $Folder.FullName )|Sort-Object -Property Name -Descending|Select-Object -First 1
    Write-Verbose ("[$FunctionName] Main folder:" + $Folder.FullName)

    $ConfigTemplateFile = (Get-ChildItem -Path $Folder.FullName -Recurse -Filter 'configTemplate.json').FullName
    #    $PSScriptRoot.Replace("Functions\Public\ModuleConfigs", "Config\configTemplate.json")
    Write-Verbose ("[$FunctionName] Reading config template from " + $ConfigTemplateFile)

    $Configs = Get-Content -Path $ConfigTemplateFile -Raw | ConvertFrom-Json
    Write-Verbose "[$FunctionName] Config template read successfully. Creating config file with default settings from template."


    $ConfigFilePath = "$ENV:Userprofile\AppData\Local\SQLPack" 
    Write-Verbose "[$FunctionName] Config file path set to $ConfigFilePath"

    if (! (Test-Path $ConfigFilePath)) { New-Item -ItemType Directory -Path $ConfigFilePath }
    Write-Verbose "[$FunctionName] Config directory verified at $ConfigFilePath"


    $ConfigFilePath = $ConfigFilePath + "\Configs.json"
    if (Test-Path -Path $ConfigFilePath) {
        if ($Force) { Write-Verbose "[$FunctionName] Overriding existing config file at $ConfigFilePath" }
        else { Write-Verbose "[$FunctionName] Config file already exists at $ConfigFilePath. Use -Force to overwrite it." ; return }
    }       
    
    Write-Verbose "[$FunctionName] Creating config file at $ConfigFilePath"
    $Configs | convertto-json -Depth 5 | Out-File -FilePath $ConfigFilePath -Encoding utf8 -Force
    Write-Verbose "[$FunctionName] Config file created at $ConfigFilePath with default settings from $ConfigTemplateFile" 

}