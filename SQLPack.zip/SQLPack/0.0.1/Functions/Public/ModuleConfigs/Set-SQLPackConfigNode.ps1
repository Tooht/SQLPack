function Set-SQLPackConfigNode {
    param (
        [Parameter(ParameterSetName = 'Value', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Default', Mandatory = $true)]
        [string] $ConfigPath,

        [Parameter(ParameterSetName = 'Value', Mandatory = $true)]
        [Parameter(ParameterSetName = 'Default', Mandatory = $false)]
        [string] $ConfigNewValue,

        [Parameter(ParameterSetName = 'Value', Mandatory = $false)]
        [Parameter(ParameterSetName = 'Default', Mandatory = $true)]
        [switch] $UseDefault
        
    )
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] Set-SQLPackConfigNode called with ConfigPath=$ConfigPath and NodeValue=$NodeValue"

    $ConfigFilePath = "$ENV:Userprofile\AppData\Local\SQLPack\Configs.json" 
    Write-Verbose "[$FunctionName] Config file path set to $ConfigFilePath" 

    $Configs = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
    Write-Verbose "[$FunctionName] Current Configurations loaded from file: $ConfigFilePath"

    if ($UseDefault) {
        $ConfigsNewValue = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json

        foreach ($Folder in $ConfigPath.replace("InUse", "Defaults").Split(".")) {
            $ConfigsNewValue = $ConfigsNewValue.$Folder
        }
        $ConfigNewValue = $ConfigsNewValue
    }
    Write-Verbose "[$FunctionName] New value define to :'$ConfigNewValue'"

    $S0 = $ConfigPath.Split(".")[0]
    $S1 = $ConfigPath.Split(".")[1]
    $S2 = $ConfigPath.Split(".")[2]
    $S3 = $ConfigPath.Split(".")[3]
    $S4 = $ConfigPath.Split(".")[4]

    $C = ($ConfigPath.Split(".")).Count

    switch ($C) {
        1 { $Configs.$S0 = $ConfigNewValue }
        2 { $Configs.$S0.$S1 = $ConfigNewValue }
        3 { $Configs.$S0.$S1.$S2 = $ConfigNewValue }
        4 { $Configs.$S0.$S1.$S2.$S3 = $ConfigNewValue }
        5 { $Configs.$S0.$S1.$S2.$S3.$S4 = $ConfigNewValue }
    }

    $script:Configs = $Configs
    Write-Verbose "[$FunctionName] Configs Variable Updated to value: $ConfigNewValue"

    $Configs | convertto-json -Depth 5 | Out-File -FilePath $ConfigFilePath -Encoding utf8 -Force
    Write-Verbose "[$FunctionName] Config file $ConfigFilePath Updated"

    Write-Verbose "[$FunctionName] Finished Get-SQLPackConfig function"


}