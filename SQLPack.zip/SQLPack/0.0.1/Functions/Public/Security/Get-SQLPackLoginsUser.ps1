function Get-SQLPackLoginsUser {
    param (      
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated,

        [Parameter(Mandatory = $true)]
            [string]$LoginName
    )
    $FunctionName=(Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] Preparing to retrieve SQL Agent job category names with filters: CategoryName='$CategoryName'"

    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] LoginName: $LoginName"

    $Query = "
DECLARE @TSQL		NVARCHAR(2000)
DECLARE @lC			INT
DECLARE @TempLog	TABLE (LogDate DATETIME,ProcessInfo NVARCHAR(50),[Text] NVARCHAR(MAX))
DECLARE @logF		TABLE (ArchiveNumber INT, LogDate DATETIME, LogSize INT)

INSERT INTO @logF EXEC sp_enumerrorlogs

SELECT @lC = MIN(ArchiveNumber) FROM @logF

WHILE @lC IS NOT NULL
BEGIN
        INSERT INTO @TempLog EXEC sp_readerrorlog @lC
	    SELECT @lC = MIN(ArchiveNumber) FROM @logF WHERE ArchiveNumber > @lC
END

SELECT [Text],COUNT([Text]) Number_Of_Attempts, MIN(LogDate) as FirstOccurrence, MAX(LogDate) as LastOccurrence
FROM @TempLog 
WHERE UPPER(ProcessInfo) = 'LOGON' AND [Text] like '%''$LoginName''%'
Group by [Text]
ORDER BY 4 DESC
											
"
    Write-Verbose "[$FunctionName] Executing query: $Query"

    return (Format-Result (Invoke-SQLIntQuery -SQLQuery $Query) $NotFomated)
}

