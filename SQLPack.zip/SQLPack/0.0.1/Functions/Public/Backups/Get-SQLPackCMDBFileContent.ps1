﻿function Get-SQLPackCMDBFileContent{ 
param (
        [Parameter(Mandatory=$false)]
            [string]$FileLocation="C:\cmdb"
    )
        
    $DIFF=(Get-Content -Path "$FileLocation\cmdb_sql_lastbackup_diff.txt")
    $FULL=(Get-Content -Path "$FileLocation\cmdb_sql_lastbackup_full.txt")

    $yourData = @(
    @{File="cmdb_sql_lastbackup_diff";Date="$DIFF"},
    @{File="cmdb_sql_lastbackup_full";Date="$FULL"}) | ForEach-Object { New-Object object | Add-Member -NotePropertyMembers $_ -PassThru }
    $yourData |Format-Table


 }