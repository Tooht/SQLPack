﻿function Get-SQLPackRestoreHistory{ 
param (
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated,
            
        [Parameter(Mandatory=$false)]
            [ArgumentCompleter({Get-SQLPackDatabasesNames } )]
            [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames)} )]
            [string]$DatabaseName,

        [Parameter(Mandatory=$false)]
            [int]$MaxRecords=100,    

        [Parameter(Mandatory=$false)]
            [ValidateSet("LastYear","LastMonth","LastWeek","LastDay")]
            [string]$Period
                )

    Switch ($Period){
        "LastYear"  {$Filter=" WHERE restore_date > DATEADD(Year,-1,GETDATE()) "}
        "LastMonth" {$Filter=" WHERE restore_date > DATEADD(Month,-1,GETDATE()) "}
        "LastWeek"  {$Filter=" WHERE restore_date > DATEADD(Week,-1,GETDATE()) "}
        "LastDay"   {$Filter=" WHERE restore_date > DATEADD(Day,-1,GETDATE()) "}
        Default     {$Filter=" WHERE restore_date > DATEADD(Month,-1,GETDATE()) "}
    }


    if ($DatabaseName){
        $Filter= $Filter + " AND UPPER(destination_database_name) LIKE UPPER('"+($DatabaseName.Replace("*","%"))+"') "
        }
        
    $query = "SELECT TOP ($MaxRecords)
                [restore_date],
                [destination_database_name],
                [user_name],
                [backup_set_id],
                [restore_type],
                [replace],
                [recovery],
                [restart] 
                FROM [msdb].[dbo].[restorehistory]
                $Filter
                Order by restore_date desc"

    return (Format-Result -Result (Invoke-SQLIntQuery -SQLQuery $Query) -NotFomated $NotFomated)
}
