﻿function Get-SQLPackDatabases { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,
            
            
        [Parameter(Mandatory = $false)]
        [string] $DatabaseName,

        [Parameter(Mandatory = $false)]
        [ValidateSet("SystemDatabases", "UserDatabases")]
        [string] $DatabasesType
    )

    $Filter = " WHERE 1=1 "

    switch ($DatabasesType) {
        "SystemDatabases" {$Filter = $Filter + " AND D.name     IN(N'master',N'model',N'tempdb',N'msdb',N'SSISDB') "}
        "UserDatabases" {$Filter = $Filter + " AND D.name NOT IN(N'master',N'model',N'tempdb',N'msdb',N'SSISDB') "}
    }

    if ($DatabaseName) { $Filter = $Filter + " AND D.name like '" + ($DatabaseName.Replace("*", "%")) + "'"}
    
    $Query = "SELECT D.name as 'DatabaseName', suser_sname( D.owner_sid ) as 'DBOwner', D.create_date as 'CreateDate', D.compatibility_level as 'Comp.Level', D.collation_name as 'Collation', 
                user_access_desc as 'user_access', state_desc as 'Status', recovery_model_desc as 'RecoveryModel'
            FROM master.sys.databases D
            $Filter " 
    
    return (Format-Result (Invoke-SQLIntQuery -SQLQuery $Query) $NotFomated)

}
