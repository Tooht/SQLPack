function Import-SQLPackJson {
    param (
        [Parameter(Mandatory = $true)]
        [string]$FilePath
    )
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    if (-not(Test-Path -Path $FilePath)) {
        Write-Verbose "[$FunctionName] Json File $FilePath dont exists "

        $ret = @{
            Success      = $false
            ErrorMessage = "File not found: $FilePath" 
        }
    }
    else {
        try {
            $ret = Get-Content -Path $FilePath -Raw | ConvertFrom-Json
            Write-Verbose "[$FunctionName] Json data imported"

        }
        catch {
            Write-Verbose "[$FunctionName] Error: $_"
            $ret = @{
                Success      = $false
                ErrorMessage = $_.Exception.Message
            }   
            
        }
    }
    
    Write-Verbose "[$FunctionName] FUNCTION END"
    return $ret
}