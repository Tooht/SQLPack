function New-SQLPackFolder {
    param (      
        [Parameter(Mandatory = $true,
                    Position = 0)]
        [string] $FolderPath,

        [Parameter(Mandatory = $false)]
        [ValidateSet("ClearContent", "RenameOld", "RenameNew", "Abort", "Ignore", "Error")]
        [string]$IfExists = "Ignore",

        [Parameter(Mandatory = $false)]
        [string] $RenameSufix = ((Get-Date).ToString("yyyyMMdd.hhmmss")),

        [Parameter(Mandatory = $false)]
        [switch] $Silent
    )
 
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"
    
    Write-Verbose "[$FunctionName] FolderPath='$FolderPath'"
    Write-Verbose "[$FunctionName] IfExists='$IfExists'"
    Write-Verbose "[$FunctionName] RenameSufix='$RenameSufix'"
    Write-Verbose "[$FunctionName] Silent='$Silent'"

    If ( -not (Test-Path -Path $FolderPath -PathType Container)) {
        $Obj = New-Item -Path $FolderPath -ItemType Directory  
        Write-Verbose "[$FunctionName] Folder created with success"

        $Return = @{
            Success = $true
            Message = "Folder created with success"
            Object  = $Obj
        }    
    }
    else {
         Write-Verbose "[$FunctionName] Folder Already Exists"

        SWITCH ($IfExists) {
            "ClearContent" {
               Get-ChildItem -Path $FolderPath -Recurse | Remove-Item
                Write-Verbose "[$FunctionName] Folder already exists, removed all child itens"

                $Return = @{
                    Success = $true
                    Message = "Folder already exists, removed all child itens"
                    Object  = (Get-Item -Path $FolderPath)
                }
            }
            "RenameOld" {
                $OldFolder = $FolderPath + $RenameSufix
                $Obj = Rename-Item -Path $FolderPath -NewName $OldFolder
                $Obj = New-Item -Path $FolderPath -ItemType Directory    
                Write-Verbose "[$FunctionName] Folder created with success, existing folder renamed to $OldFolder"

                $Return = @{
                    Success = $true
                    Message = "Folder created with success, existing folder renamed to $OldFolder"
                    Object  = $Obj
                }
            }
            "RenameNew" {
                $NewName= ($FolderPath +"."+ $RenameSufix)
                $Obj = New-Item -Path $NewName -ItemType Directory    
                Write-Verbose "[$FunctionName] Folder created with success, new folder named to $NewName"

                $Return = @{
                    Success = $true
                    Message = "Folder created with success, new folder named to $NewName"
                    Object  = $Obj
                }
            }
            "Abort" {
                Write-Verbose "[$FunctionName] Folder already exists, creation aborted"
                
                $Return = @{
                    Success = $false
                    Message = "Folder already exists, creation aborted"
                    Object  = $null
                }
            }
            "Ignore" {
                Write-Verbose "[$FunctionName] Folder already exists, creation ignored"
                
                $Return = @{
                    Success = $false
                    Message = "Folder already exists, creation ignored"
                    Object  = (Get-Item -Path $FolderPath)
                }
            }
            "Error" {
                Write-Verbose "[$FunctionName] Folder aready exists, throw error"
                Write-Error -Message "Folder aready exists" -ErrorId IO1001 -Category "WriteError" -Reason "Folder exists and 'IfExists' parameter set to $IfExists"
                
                $Return = @{
                    Success = $false
                    Message = "Folder aready exists, throw error"
                    Object  = $null
                }
            }
        }
    }

    Write-Verbose "[$FunctionName] END START"
    If (-not $Silent) {return $Return}
}


