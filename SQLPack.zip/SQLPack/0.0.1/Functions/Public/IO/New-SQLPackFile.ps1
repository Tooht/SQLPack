function New-SQLPackFile {
    param (      
        [Parameter(ParameterSetName = 'FullName', 
            Mandatory = $true, 
            Position = 0)]
        [string] $FileFullName,

        [Parameter(ParameterSetName = 'SplitName', 
            Mandatory = $true)]
        [string] $FolderPath,

        [Parameter(ParameterSetName = 'SplitName',
            Mandatory = $true)]
        [string] $FileName,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Override", "RenameOld", "RenameNew", "Abort", "Ignore", "Error")]
        [string]$IfExists = "Abort",

        [Parameter(Mandatory = $false)]
        [string] $RenameSufix = ((Get-Date).ToString("yyyyMMdd.hhmmss")),

        [Parameter(Mandatory = $false)]
        [switch] $Silent,

        [Parameter(Mandatory = $false)]
        [switch] $CreateFolder

    )
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"
    
    if (-not $FileFullName) {$FileFullName = Join-Path -Path  $FolderPath -ChildPath $FileName }
    if (-not $FolderPath) { $FolderPath = Split-Path -Path $FileFullName -Parent}
    if (-not $FileName) { $FileName = Split-Path -Path $FileFullName -Leaf}
    Write-Verbose "[$FunctionName] FileFullName='$FileFullName'"
    Write-Verbose "[$FunctionName] FolderPath='$FolderPath'"
    Write-Verbose "[$FunctionName] FileName='$FileName'"
    Write-Verbose "[$FunctionName] IfExists='$IfExists'"
    Write-Verbose "[$FunctionName] RenameSufix='$RenameSufix'"
    Write-Verbose "[$FunctionName] Silent='$Silent'"
    Write-Verbose "[$FunctionName] CreateFolder='$CreateFolder'"
    
    Write-Verbose "[$FunctionName] Start Parameters validation"

    if ( $FileName -notlike '*.*' -or $FileName -eq $null) {
        Write-Verbose "[$FunctionName] Neither FileFullName parameter or FileName parameter contains a valid file name"
        
        return @{
            Success = $false
            Message = "Invalid File Name"
            Object  = $null
        } 
    }

    if ( -not $FolderPath ) {
        Write-Verbose "[$FunctionName] Neither FileFullName parameter or FolderPath parameter contains a valid folder path"
        
        return @{
            Success = $false
            Message = "Invalid Folder Path"
            Object  = $null
        } 
    }

    if ( -not (Test-Path $FolderPath -PathType Container )) {
        Write-Verbose "[$FunctionName] Folder $FolderPath dont exists"

        if ($CreateFolder) {
            $Obj = New-Item -Path $FolderPath -ItemType Directory
            Write-Verbose "[$FunctionName] Folder $FolderPath created with success"
        }
        else {
            Write-Verbose "[$FunctionName] Parameter CreateFolder not active, so folder not created"

            return @{
                Success = $false
                Message = "Folder Dont Exists"
                Object  = $null
            }
        } 
    }
    Write-Verbose "[$FunctionName] All Parameters validated"

    If ( -not (Test-Path -Path $FileFullName -PathType Leaf)) {
        $Obj = New-Item -Path $FileFullName -ItemType File  
        Write-Verbose "[$FunctionName] File created with success"

        $Return = @{
            Success = $true
            Message = "File created with success"
            Object  = $Obj
        }    
    }
    else {
        Write-Verbose "[$FunctionName] File Already Exists"

        SWITCH ($IfExists) {
            "Override" {
                $Obj = New-Item -Path $FileFullName -ItemType File  -Force
                Write-Verbose "[$FunctionName] File created with success, overrided existing file"
                
                $Return = @{
                    Success = $true
                    Message = "File created with success, overrided existing file"
                    Object  = $Obj
                }
            }
            "RenameOld" {
                $OldFile = Get-Item -Path $FileFullName
                $NewName = ($OldFile.BaseName + "." + $RenameSufix + "." + $OldFile.Extension)
                $Obj = Rename-Item -Path $OldFile.FullName -NewName $NewName
                $Obj = New-Item -Path $FileFullName -ItemType File    
                Write-Verbose "[$FunctionName] File created with success, existing file renamed to $NewName"

                $Return = @{
                    Success = $true
                    Message = "File created with success, existing file renamed to $NewName"
                    Object  = $Obj
                }
            }
            "RenameNew" {
                $OldFile = Get-Item -Path $FileFullName
                $NewName = ($OldFile.BaseName + "." + $RenameSufix + "." + $OldFile.Extension)
                $FileFullName = Join-Path -Path $OldFile.Directory.FullName -ChildPath $NewName
                $Obj = New-Item -Path $FileFullName -ItemType File      
                Write-Verbose "[$FunctionName] File created with success, new file renamed to $NewName"

                $Return = @{
                    Success = $true
                    Message = "File created with success, new file renamed to $NewName"
                    Object  = $Obj
                }
            }
            "Abort" {
                Write-Verbose "[$FunctionName] File aready exists, creation aborted"
                
                $Return = @{
                    Success = $false
                    Message = "File aready exists, creation aborted"
                    Object  = $null
                }
            }
            "Ignore" {
                Write-Verbose "[$FunctionName] File aready exists, creation Ignored"
                
                $Return = @{
                    Success = $false
                    Message = "File aready exists, creation Ignored"
                    Object  = Get-Item -Path $FileFullName -ItemType file
                }
            }
            "Error" {
                Write-Verbose "[$FunctionName] File aready exists, throw error"
                Write-Error -Message "File aready exists" -ErrorId IO0002 -Category "WriteError" -Reason "File exists and 'IfExists' parameter set to $IfExists"
                
                $Return = @{
                    Success = $false
                    Message = "File aready exists, throw error"
                    Object  = $null
                }
            }
        }
    }

    Write-Verbose "[$FunctionName] END START"
    If (-not $Silent) {return $Return}
}


