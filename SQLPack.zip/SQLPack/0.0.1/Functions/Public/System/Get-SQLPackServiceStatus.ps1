﻿function Get-SQLPackServiceStatus {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [string]$ServiceName ,
            
        [Parameter(Mandatory = $false)]
        [string]$DisplayName ,
            
        [Parameter(Mandatory = $false)]
        [ValidateSet("Running", "paused", "starting", "pausing", "stopping", "stopped")]
        [string]$State,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Boot", "System", "Auto", "Manual", "Disabled")]
        [string]$StartMode
    )
    $Result = Get-WmiObject Win32_Service -ComputerName localhost | 
        Select-Object DisplayName, @{Name = 'LogonName'; Expression = {$_.StartName}}, ProcessId, State, StartMode

    if ($ServiceName) {$Result = $Result|Where-Object -Property Name -Like $ServiceName}

    if ($DisplayName) {$Result = $Result|Where-Object -Property DisplayName -Like $DisplayName}
    if (!$DisplayName -and !$ServiceName) {$Result = $Result|Where-Object -Property DisplayName -Like "*SQL*"}

    if ($State) {$Result = $Result|Where-Object -Property State -eq $State}

    if ($StartMode) {$Result = $Result|Where-Object -Property StartMode -eq $StartMode}


    return (Format-Result $Result $NotFomated)

}