﻿function Get-SQLPackDriveList{ 
param (
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated
                )

    $Result=Get-CimInstance -ClassName Win32_LogicalDisk | 
                Where-Object {$_.DriveType -eq 3} | 
                Select-Object DeviceID,VolumeName, @{Name="SizeGB"; Expression={[Math]::Floor(($_.Size/1GB))}},@{Name="FreeGB"; Expression={[Math]::Floor(($_.FreeSpace/1GB))}}

    return (Format-Result $Result $NotFomated)
  }