﻿
function Get-SQLPackAlwaysOnHistory{
 param (
        [Parameter(Mandatory=$false)]
            [int] $MaxRecords=100,
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated
    )

    $Query="DECLARE @xel_path VARCHAR(1024);
            DECLARE @utc_adjustment INT = DATEDIFF(HOUR, GETUTCDATE(), GETDATE());
            
            ;WITH target_data_cte AS
                (SELECT target_data = 
                        convert(xml, target_data)
                   FROM sys.dm_xe_sessions s
                   INNER JOIN sys.dm_xe_session_targets st
                        ON s.address = st.event_session_address
                    WHERE s.name = 'alwayson_health'
                      AND st.target_name = 'event_file'),
            full_path_cte as
                (SELECT full_path = target_data.value('(EventFileTarget/File/@name)[1]', 'varchar(1024)')
                 FROM target_data_cte )
            SELECT @xel_path =  LEFT(full_path, LEN(full_path) - charindex('\', reverse(full_path))) + '\AlwaysOn_health*.xel'
            FROM full_path_cte;
            
            ;WITH state_change_data AS
                (SELECT object_name,
                        event_data = CONVERT(xml, event_data)
                 FROM sys.fn_xe_file_target_read_file(@xel_path, null, null, null))
            SELECT object_name,
                event_timestamp = dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')),
                ag_name = event_data.value('(event/data[@name = ""availability_group_name""]/value)[1]', 'varchar(64)'),
                previous_state = event_data.value('(event/data[@name = ""previous_state""]/text)[1]', 'varchar(64)'),
                current_state = event_data.value('(event/data[@name = ""current_state""]/text)[1]', 'varchar(64)')
            FROM state_change_data
            WHERE object_name = 'availability_replica_state_change'
            ORDER BY event_timestamp desc;"
    

      return (Format-Result -Result (Invoke-SQLIntQuery -SQLQuery $Query) -NotFomated $NotFomated)

}
