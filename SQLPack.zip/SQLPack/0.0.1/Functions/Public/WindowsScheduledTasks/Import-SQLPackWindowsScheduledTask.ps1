function Import-SQLPackWindowsScheduledTask {
    param (      
        [Parameter(Mandatory = $true)]
        [string] $SourceFolder ,

        [Parameter(Mandatory = $true)]
        [string] $FileName  ,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Override", "Abort", "Ignore", "Error")]
        [string]$IfExists    
    )
    $FunctionName = (Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] SourceFolder='$SourceFolder'"
    Write-Verbose "[$FunctionName] FileName='$FileName'"
    Write-Verbose "[$FunctionName] IfExists='$IfExists'"

    Write-Verbose "[$FunctionName] Parameter validation"

    if (-not(Test-Path $SourceFolder)) {
        Write-Verbose "[$FunctionName] Source folder '$SourceFolder' dont exists"
        return @{
            Success = $false
            Message = "Source folder dont exists"
            Status  = "Error"
        }
    }

    $Tasks = ""
    $iCount = 0
    Get-ChildItem -Path $SourceFolder -Filter $FileName | ForEach-Object {
        IF (Get-ScheduledTask -TaskName $_.BaseName -ErrorAction SilentlyContinue) {
            Write-Verbose "[$FunctionName] Task '$_.BaseName' already exists"
            Switch ($IfExists) {
                "Override" {
                    $R = Register-ScheduledTask -xml (Get-Content $_.FullName | Out-String)  -TaskName $_.BaseName -CimSession . -Force
                    $Tasks += $_.BaseName + ";"
                    Write-Verbose "Task $_.TaskName Imported with success, overrided existing task" 
                }
                "Abort" {
                    Write-Verbose "[$FunctionName] Task '$_.BaseName' already exists and IfExists set to '$IfExists'"
                    return @{
                        Success = $false
                        Message = "Task '$_.BaseName' already exists"
                        Status  = "Aborted"
                    }
                }
                "Ignore" {
                    Write-Verbose "Task $_.TaskName NOT Imported" 
                }
                "Error" {
                    Write-Verbose "[$FunctionName] Task '$_.BaseName' already exists, throw error"
                    Write-Error -Message "Task '$_.BaseName' already exists" -ErrorId IO0002 -Category "WriteError" -Reason "Task '$_.BaseName' already exists"
                
                    return @{
                        Success = $false
                        Message = "File aready exists, throw error"
                        Status  = $"Error"
                    }
                }
            }
        }
        else {
              
            $R = Register-ScheduledTask -xml (Get-Content $_.FullName | Out-String)  -TaskName $_.BaseName -CimSession .
            $Tasks += $_.BaseName + "; "
            
            Write-Verbose "Task $_.TaskName Imported with success" 
           
        }
        $iCount += 1

    }
    return @{
        Success = $true
        Message = "Imported Tasks: $Tasks "
        Status  = "Completed"
    }


    Write-Verbose "[$FunctionName] $iCount Tasks Imported"
    Write-Verbose "[$FunctionName] END START"
}