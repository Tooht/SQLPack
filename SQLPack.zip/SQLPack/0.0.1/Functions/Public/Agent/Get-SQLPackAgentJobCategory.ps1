function Get-SQLPackAgentJobCategory {
    param (      
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
            [string]$CategoryName,

        [Parameter(Mandatory = $false)]
        [switch] $SimpleList,

        [Parameter(Mandatory = $false)]
        [switch] $OnlyInUse

    )
    $FunctionName=(Get-SQLIntFunctionName)
    Write-Verbose "[$FunctionName] Preparing to retrieve SQL Agent job category names with filters: CategoryName='$CategoryName'"

    if (!$SimpleList)
    {$Fields="
,C.category_id AS [CategoryID],
C.category_class AS [CategoryClassID],
Case C.category_class 
	When 1 then 'Job'
	When 2 then 'Alert'
	When 3 then 'Operator'
	Else null
END	AS [CategoryClassDesc],
C.category_type AS [CategoryTypeID],
CASE C.category_type 
	WHEN 1 THEN 'Local'
	WHEN 2 THEN 'Multiserver'
	WHEN 3 THEN 'None'
END AS [CategoryTypeDesc],
CASE WHEN J.job_id is null THEN 0 ELSE 1 END AS InUse
"}

If($CategoryName.Length -gt 0)
{$FilterCategory=" and name like '" + ($CategoryName.Replace("*","%")) + "' "}

If($OnlyInUse)
{$FilterOnlyInUse= " AND J.job_id IS NOT NULL "}

    $Query = "
    SELECT DISTINCT 
C.name AS [CategoryName] $Fields
FROM msdb..syscategories C
LEFT JOIN msdb.dbo.sysjobs J
ON C.category_id=J.category_id
WHERE 1=1 $FilterCategory $FilterOnlyInUse
"
    Write-Verbose "[$FunctionName] Executing query: $Query"

    IF($SimpleList){    return (Invoke-SQLIntQuery -SQLQuery $Query).CategoryName}
    else {return (Format-Result (Invoke-SQLIntQuery -SQLQuery $Query) $NotFomated)}
}