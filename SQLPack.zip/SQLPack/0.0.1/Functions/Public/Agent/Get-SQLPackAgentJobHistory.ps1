﻿function Get-SQLPackAgentJobHistory { 
    param (
        [Parameter(Mandatory = $false)]
        [int] $MaxRecords = 100,
        
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,
            
        [Parameter(Mandatory = $false)]
        [switch]$IncludeSteps,
            
        [Parameter(Mandatory = $false)]
        [switch]$IncludeMessage,

        [Parameter(Mandatory = $false)]
        [string]$Name,

        [Parameter(Mandatory = $false)]
        [ArgumentCompleter( {(Get-SQLPackAgentJobCategory -SimpleList -OnlyInUse|Select-Object -Property @{Label = "CategoryName"; Expression = {"'$_'"}}).CategoryName})]
        [ValidateScript( {(Get-SQLPackAgentJobCategory -SimpleList -OnlyInUse|Select-Object -Property @{Label = "CategoryName"; Expression = {"'$_'"}}).CategoryName})]
        [string]$CategoryName,
            
        [Parameter(Mandatory = $false)]
        [ValidateSet("Failed", "Succeeded", "Retry", "Canceled", "In Progress")]
        [string[]]$Status
    )

    if ($IncludeSteps) {
        $FieldSteps = ", h.step_name"
        Write-Verbose "IncludeSteps Set True"
    }

    if ($IncludeMessage) {
        $FieldMessage = ", h.message"
        Write-Verbose "IncludeMessage Set True"
    }

    $Filter = " WHERE 1=1 "

    if ($Name) {
        $Filter = $Filter + " AND UPPER([j].[name]) LIKE UPPER('" + $Name.Replace("*", "%") + "') "
        Write-Verbose "Name parameter: $Name"
    }

    if ($Category) {
        $Filter = $Filter + " AND [c].[name] ='" + $Category + "' "
        Write-Verbose "Category parameter: $Category"
    }
        foreach ($S in $Status) {
            Switch ($S) {
        
                "Failed" {$FilterStatus = $FilterStatus += ", 0 "}
                "Succeeded" {$FilterStatus = $FilterStatus += ", 1 "}
                "Retry" {$FilterStatus = $FilterStatus += ", 2 "} 
                "Canceled" {$FilterStatus = $FilterStatus += ", 3 "}
                "In Progress" {$FilterStatus = $FilterStatus += ", 4 "}
            }
        }

        if($FilterStatus.Length -gt 0)
        {$Filter += " and h.run_status in ("+( $FilterStatus.Substring(2))+")"}



        $query = "SELECT DISTINCT j.name Name
        ,c.name as Category
        $FieldSteps
        ,CONVERT(CHAR(10), CAST(STR(MAX(h.run_date),8, 0) AS dateTIME), 111) RunDate
        ,STUFF(STUFF(RIGHT('000000' + CAST ( MAX(h.run_time) AS VARCHAR(6 ) ) ,6),5,0,':'),3,0,':') RunTime
        ,SUM((run_duration/10000*3600 + (run_duration/100)%100*60 + run_duration%100  ) )  StepDuration
        ,case h.run_status when 0 then 'failed'
		        when 1 then 'Succeded' 
		        when 2 then 'Retry' 
		        when 3 then 'Cancelled' 
		        when 4 then 'In Progress' 
	        end as ExecutionStatus
        $FieldMessage
        FROM msdb.dbo.sysjobhistory h 
        INNER JOIN msdb.dbo.sysjobs j ON j.job_id = h.job_id
        INNER JOIN msdb.dbo.syscategories c on j.category_id = c.category_id
        $Filter
        GROUP BY j.name, c.name $FieldSteps, h.run_status $FieldMessage
        ORDER BY  RunDate desc ,RunTime desc"
 
        $query
    
        return (Format-Result (Invoke-SQLIntQuery -SQLQuery $Query) $NotFomated)
    }