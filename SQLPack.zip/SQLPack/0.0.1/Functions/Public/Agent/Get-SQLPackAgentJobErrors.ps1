
function Get-SQLPackAgentJobErrors
 { 
    param (
        [Parameter(Mandatory = $false)]
            [int] $MaxRecords = 100,
        [Parameter(Mandatory = $false)]
            [switch] $NotFomated,
            
        [Parameter(Mandatory = $false)]
            [string]$JobName,

        [Parameter(Mandatory = $false)]
            [ArgumentCompleter( {(Get-SQLPackAgentJobCategory -SimpleList -OnlyInUse|Select-Object -Property @{Label = "CategoryName"; Expression = {"'$_'"}}).CategoryName})]
            [ValidateScript( {(Get-SQLPackAgentJobCategory -SimpleList -OnlyInUse|Select-Object -Property @{Label = "CategoryName"; Expression = {"'$_'"}}).CategoryName})]
            [string]$CategoryName
    )


    $Filter = " WHERE 1=1 "


    if ($JobName) {
        $Filter = $Filter + " AND SysJobs.name LIKE '" + $JobName.Replace("*", "%") + "' "
        Write-Verbose "JobName parameter: $JobName"
    }

    if ($CategoryName) {
        $Filter = $Filter + " AND SysJobCat.name = '$CategoryName' "
        Write-Verbose "CategoryName parameter: $CategoryName"
    }

    $query = "SELECT TOP($MaxRecords) SysJobs.name as job_name,
		SysJobSteps.step_name as step_name, 
		SysJobCat.name as category_name,
		Job.run_status, 
		Job.sql_message_id, 
		Job.sql_severity
        ,Job.message, 
		Job.exec_date, 
		Job.run_duration, 
		Job.server,
        SysJobSteps.output_file_name
FROM    (SELECT Instance.instance_id ,
				JH.job_id ,JH.step_id ,
				JH.sql_message_id ,
				JH.sql_severity ,
				JH.message,
				(CASE JH.run_status WHEN 0 THEN 'Failed' WHEN 1 THEN 'Succeeded' WHEN 2 THEN 'Retry' WHEN 3 THEN 'Canceled' WHEN 4 THEN 'In progress' END) as run_status,
				((SUBSTRING(CAST(JH.run_date AS VARCHAR(8)), 5, 2) + '/' 
					+ SUBSTRING(CAST(JH.run_date AS VARCHAR(8)), 7, 2) + '/' 
					+ SUBSTRING(CAST(JH.run_date AS VARCHAR(8)), 1, 4) + ' '
					+ SUBSTRING((REPLICATE('0',6-LEN(CAST(JH.run_time AS varchar))) + CAST(JH.run_time AS VARCHAR)), 1, 2) + ':'
					+ SUBSTRING((REPLICATE('0',6-LEN(CAST(JH.run_time AS VARCHAR))) + CAST(JH.run_time AS VARCHAR)), 3, 2) + ':'
					+ SUBSTRING((REPLICATE('0',6-LEN(CAST(JH.run_time as varchar))) + CAST(JH.run_time AS VARCHAR)), 5, 2))) AS 'exec_date',
				JH.run_duration ,
				JH.retries_attempted ,
				JH.server
        FROM msdb.dbo.sysjobhistory JH
        JOIN (SELECT JH.job_id ,
					JH.step_id ,
					MAX(JH.instance_id) as instance_id 
				FROM msdb.dbo.sysjobhistory JH 
				GROUP BY JH.job_id ,JH.step_id) AS Instance 
		ON JH.instance_id = Instance.instance_id
        WHERE JH.run_status <> 1) AS Job
JOIN msdb.dbo.sysjobs SysJobs 
	ON (Job.job_id = SysJobs.job_id)
JOIN msdb.dbo.sysjobsteps SysJobSteps 
	ON (Job.job_id = SysJobSteps.job_id AND Job.step_id = SysJobSteps.step_id)
LEFT JOIN msdb.dbo.syscategories SysJobCat
	ON (SysJobs.category_id=SysJobCat.category_id)
$Filter"
 
    return (Format-Result (Invoke-SQLIntQuery -SQLQuery $Query) $NotFomated)
}