﻿
function Get-SQLPackAgentJobList { 
    param (
        [Parameter(Mandatory = $false)]
            [int] $MaxRecords = 100,
        [Parameter(Mandatory = $false)]
            [switch] $NotFomated,
            
        [Parameter(Mandatory = $false)]
            [switch]$ExcludeDisabled,

        [Parameter(Mandatory = $false)]
            [switch]$ExcludeNotScheduled,
        
        [Parameter(Mandatory = $false)]
            [string]$JobName,

        [Parameter(Mandatory = $false)]
            [ArgumentCompleter( {(Get-SQLPackAgentJobCategory -SimpleList -OnlyInUse|Select-Object -Property @{Label = "CategoryName"; Expression = {"'$_'"}}).CategoryName})]
            [ValidateScript( {(Get-SQLPackAgentJobCategory -SimpleList -OnlyInUse|Select-Object -Property @{Label = "CategoryName"; Expression = {"'$_'"}}).CategoryName})]
            [string]$CategoryName
    )


    $Filter = " WHERE 1=1 "

    if ($ExcludeDisabled) {
        $Filter = $Filter + " AND [sJOB].[enabled]=1 "
        Write-Verbose "ExcludeDisabled parameter: $ExcludeDisabled"
    }

    if ($ExcludeNotScheduled) {
        $Filter = $Filter + " AND [sSCH].[schedule_uid] IS NOT NULL "
        Write-Verbose "ExcludeNotScheduled parameter: $ExcludeNotScheduled"
    }

    if ($JobName) {
        $Filter = $Filter + " AND [sJOB].[name] LIKE '" + $JobName.Replace("*", "%") + "' "
        Write-Verbose "JobName parameter: $JobName"
    }

    if ($CategoryName) {
        $Filter = $Filter + " AND [sCat].[name] = '$CategoryName' "
        Write-Verbose "CategoryName parameter: $CategoryName"
    }




    $query = "WITH J as ( SELECT [job_id], [run_status]
            FROM [msdb].[dbo].[sysjobhistory]
            WHERE [step_id] = 0)
SELECT DISTINCT [sJOB].[name] AS [JobName] ,
    CASE [sJOB].[enabled]
        WHEN 1 THEN 'Yes'
        WHEN 0 THEN 'No'
    END AS [IsEnabled] ,
    CASE
		WHEN [sSCH].[schedule_uid] IS NULL THEN 'No'
		ELSE 'Yes'
    END AS [IsScheduled],
	[sCat].[name] as Category,
    [sSCH].[name] AS [JobScheduleName],
    CASE J.run_status
		WHEN 0 THEN 'Failed'
		WHEN 1 THEN 'Succeeded'
		WHEN 2 THEN 'Retry'
		WHEN 3 THEN 'Canceled'
		WHEN 4 THEN 'Running' 
		ELSE 'Unknown'
	END AS [LastRunStatus]
FROM
    [msdb].[dbo].[sysjobsteps] AS [sJSTP]
    INNER JOIN [msdb].[dbo].[sysjobs] AS [sJOB] ON [sJSTP].[job_id] = [sJOB].[job_id]
    LEFT JOIN [msdb].[dbo].[sysjobschedules] AS [sJOBSCH] ON [sJOB].[job_id] = [sJOBSCH].[job_id]
    LEFT JOIN [msdb].[dbo].[sysschedules] AS [sSCH] ON [sJOBSCH].[schedule_id] = [sSCH].[schedule_id]
    LEFT JOIN J ON J.job_id=sJOB.job_id
	LEFT JOIN [msdb].[dbo].[syscategories] sCat ON sJOB.category_id =sCat.category_id
$Filter
ORDER BY [JobName] "
 
    return (Format-Result (Invoke-SQLIntQuery -SQLQuery $Query) $NotFomated)
}
