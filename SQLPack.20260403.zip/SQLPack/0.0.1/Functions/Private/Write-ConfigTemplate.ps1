function Write-ConfigTemplate {
    param(
        [Parameter(Mandatory = $true)]
        [object]$ConfigValues
    )

    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"


    $Folder = (get-item $PSScriptRoot )
    Write-Verbose "[$FunctionName] Current folder: $Folder"

    Do {
        $Folder = (get-item $Folder.FullName ).parent
    } While ($Folder.Name -ne "SQLPack") 

    $Folder = (Get-ChildItem -Path $Folder.FullName )|Where-Object {$_.BaseName -ne "SQLPack.Builder"}|Sort-Object -Property Name -Descending|Select-Object -First 1
    Write-Verbose ("[$FunctionName] Main folder:" + $Folder.FullName)

    $ConfigTemplateFile = (Get-ChildItem -Path $Folder.FullName -Recurse -Filter 'configTemplate.json').FullName
    Write-Verbose ("[$FunctionName] Reading config template from " + $ConfigTemplateFile)

    # Save the updated config to the template file as JSON
    $ConfigValues | ConvertTo-Json | Out-File -FilePath $ConfigTemplateFile -Encoding UTF8
 
    Write-Verbose "[$FunctionName] FUNCTION END"
}