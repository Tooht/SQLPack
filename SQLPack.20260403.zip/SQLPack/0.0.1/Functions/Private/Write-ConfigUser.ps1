function Write-ConfigUser {
    param(
        [Parameter(Mandatory = $true)]
        [object]$ConfigValues,
        
        [Parameter(Mandatory = $false)]        
        [switch]$Force
    )

    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    
    $ConfigFilePath = "$ENV:Userprofile\AppData\Local\SQLPack" 
    Write-Verbose "[$FunctionName] Config file path set to $ConfigFilePath"

    if (! (Test-Path $ConfigFilePath)) { New-Item -ItemType Directory -Path $ConfigFilePath }
    Write-Verbose "[$FunctionName] Config directory verified at $ConfigFilePath"


    $ConfigFilePath = $ConfigFilePath + "\Configs.json"
    if (Test-Path -Path $ConfigFilePath) {
        if ($Force) { Write-Verbose "[$FunctionName] Overriding existing config file at $ConfigFilePath" }
        else { Write-Verbose "[$FunctionName] Config file already exists at $ConfigFilePath. Use -Force to overwrite it." ; return }
    }       
    
    $ConfigValues | convertto-json -Depth 5 | Out-File -FilePath $ConfigFilePath -Encoding utf8 -Force
    Write-Verbose "[$FunctionName] Config file created at $ConfigFilePath " 
    Write-Verbose "[$FunctionName] FUNCTION END"
}