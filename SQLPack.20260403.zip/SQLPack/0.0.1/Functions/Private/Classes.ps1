
class SQLPackReturn {
    [string]$Result
    [string]$Message
    [object]$Objects

    SQLPackReturn() {
        $this.Result = ""
        $this.Message = ""
        $this.Objects = $null
    }

    SQLPackReturn([string]$Result) {
        $this.Result = $Result
        $this.Message = ""
        $this.Objects = $null
    }

    SQLPackReturn([string]$Result, [string]$Message) {
        $this.Result = $Result
        $this.Message = $Message
        $this.Objects = $null
    }
    
    SQLPackReturn([string]$Result, [string]$Message, [object]$Objects) {
        $this.Result = $Result
        $this.Message = $Message
        $this.Objects = $Objects
    }
}

class SQLPackReturnError {
    [string]$ErrorCode
    [string]$Message
    [object]$Objects
    [object]$Exception

    SQLPackReturnError() {
        $this.ErrorCode = ""
        $this.Message = ""
        $this.Objects = $null
        $this.Exception = $null
    }

    SQLPackReturnError([string]$ErrorCode) {
        $this.ErrorCode = $ErrorCode
        $this.Message = ""
        $this.Objects = $null
        $this.Exception = $null
    }

    SQLPackReturnError([string]$ErrorCode, [string]$Message) {
        $this.ErrorCode = $ErrorCode
        $this.Message = $Message
        $this.Objects = $null
        $this.Exception = $null
    }
    
    SQLPackReturnError([string]$ErrorCode, [string]$Message, [object]$Objects) {
        $this.ErrorCode = $ErrorCode
        $this.Message = $Message
        $this.Objects = $Objects
        $this.Exception = $null
    }
    
    SQLPackReturnError([string]$ErrorCode, [string]$Message, [object]$Objects, [object]$Exception) {
        $this.ErrorCode = $ErrorCode
        $this.Message = $Message
        $this.Objects = $Objects
        $this.Exception = $Exception
    }
}