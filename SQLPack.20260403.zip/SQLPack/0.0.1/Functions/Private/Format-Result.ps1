<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Format-Result {
    param (
         [Parameter(Mandatory = $false, ValueFromPipeline=$true, Position=0)]
        [Object[]]$Result
        ,
        [Parameter(Mandatory = $false, ValueFromPipeline=$true, Position=1)]
        [boolean] $NotFomated
    )

    if ($null -eq $Result) {return "No Records found" }
    Elseif ($NotFomated)   {return $Result}
    ELSE                   {return ($Result|Format-Table)}
}