<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>function New-SQLPackFile {
    param (      
        [Parameter(ParameterSetName = 'FullName', 
            Mandatory = $true, 
            Position = 0)]
        [string] $FileFullName,

        [Parameter(ParameterSetName = 'SplitName', 
            Mandatory = $true)]
        [string] $FolderPath,

        [Parameter(ParameterSetName = 'SplitName',
            Mandatory = $true)]
        [string] $FileName,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Override", "RenameOld", "RenameNew", "Abort", "Ignore", "Error")]
        [string]$IfExists = "Abort",

        [Parameter(Mandatory = $false)]
        [string] $RenameSufix = ((Get-Date).ToString("yyyyMMdd.hhmmss")),

        [Parameter(Mandatory = $false)]
        [switch] $Silent,

        [Parameter(Mandatory = $false)]
        [switch] $CreateFolder

    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "    
    if (-not $FileFullName) { $FileFullName = Join-Path -Path  $FolderPath -ChildPath $FileName }
    if (-not $FolderPath) { $FolderPath = Split-Path -Path $FileFullName -Parent }
    if (-not $FileName) { $FileName = Split-Path -Path $FileFullName -Leaf }
    Write-Verbose "[$FunctionName] FileFullName='$FileFullName'"
    Write-Verbose "[$FunctionName] FolderPath='$FolderPath'"
    Write-Verbose "[$FunctionName] FileName='$FileName'"
    Write-Verbose "[$FunctionName] IfExists='$IfExists'"
    Write-Verbose "[$FunctionName] RenameSufix='$RenameSufix'"
    Write-Verbose "[$FunctionName] Silent='$Silent'"
    Write-Verbose "[$FunctionName] CreateFolder='$CreateFolder'"

    
    Write-Verbose "[$FunctionName] Start Parameters validation"

    if ( $FileName -notlike '*.*' -or $null -eq $FileName) {
        Write-Verbose "[$FunctionName] Neither FileFullName parameter or FileName parameter contains a valid file name"
        return [SQLPackReturnError]::new("Error" + $FunctionName + "001", "Invalid File Name" , $null, $null )
    }

    if ( -not $FolderPath ) {
        Write-Verbose "[$FunctionName] Neither FileFullName parameter or FolderPath parameter contains a valid folder path"
        return [SQLPackReturnError]::new("Error" + $FunctionName + "002", "Invalid Folder Path" , $null, $null )
    }

    if ( -not (Test-Path $FolderPath -PathType Container )) {
        Write-Verbose "[$FunctionName] Folder $FolderPath dont exists"

        if ($CreateFolder) {
            $Obj = New-Item -Path $FolderPath -ItemType Directory
            Write-Verbose "[$FunctionName] Folder $FolderPath created with success"
        }
        else {
            Write-Verbose "[$FunctionName] Parameter CreateFolder not active, so folder not created"
            return [SQLPackReturnError]::new("Error" + $FunctionName + "003", "Folder Dont Exists and parameter CreateFolder not active " , $null, $null )
        } 
    }
    Write-Verbose "[$FunctionName] All Parameters validated"

    If ( -not (Test-Path -Path $FileFullName -PathType Leaf)) {
        $Obj = New-Item -Path $FileFullName -ItemType File  
        Write-Verbose "[$FunctionName] File created with success"

        return [SQLPackReturn]::new("Created", "File created with success", $Obj )

    }
    else {
        Write-Verbose "[$FunctionName] File Already Exists"

        SWITCH ($IfExists) {
            "Override" {
                $Obj = New-Item -Path $FileFullName -ItemType File  -Force
                Write-Verbose "[$FunctionName] File created with success, overrided existing file"
                
                return [SQLPackReturn]::new("Overrided", "File created with success, overrided existing file", $Obj )
            }
            "RenameOld" {
                $OldFile = Get-Item -Path $FileFullName
                $NewName = ($OldFile.BaseName + "." + $RenameSufix + "." + $OldFile.Extension)
                $Obj = Rename-Item -Path $OldFile.FullName -NewName $NewName
                $Obj = New-Item -Path $FileFullName -ItemType File    
                Write-Verbose "[$FunctionName] File created with success, existing file renamed to $NewName"

                return [SQLPackReturn]::new("RenamedExisting", "File created with success, existing file renamed to $NewName", $Obj )
            }
            "RenameNew" {
                $OldFile = Get-Item -Path $FileFullName
                $NewName = ($OldFile.BaseName + "." + $RenameSufix + "." + $OldFile.Extension)
                $FileFullName = Join-Path -Path $OldFile.Directory.FullName -ChildPath $NewName
                $Obj = New-Item -Path $FileFullName -ItemType File      
                Write-Verbose "[$FunctionName] File created with success, new file renamed to $NewName"

                return [SQLPackReturn]::new("RenamedNew", "File created with success, new file renamed to $NewName", $Obj )
            }
            "Abort" {
                Write-Verbose "[$FunctionName] File aready exists, creation aborted"
                
                return [SQLPackReturn]::new("Aborted", "File aready exists, creation aborted", $null)
            }
            "Ignore" {
                Write-Verbose "[$FunctionName] File aready exists, creation Ignored"
                
                return [SQLPackReturn]::new("Ignored", "File aready exists, creation Ignored", $null)

            }
            "Error" {
                Write-Verbose "[$FunctionName] File aready exists, throw error"
                Write-Error -Message "File aready exists" -ErrorId IO0002 -Category "WriteError" -Reason "File exists and 'IfExists' parameter set to $IfExists"
                
                return [SQLPackReturnError]::new("Error" + $FunctionName + "004", "File aready exists, throw error" , $null, $null )
            }
        }
    }

    Write-Verbose "[$FunctionName] FUNCTION END"

    If (-not $Silent) { return $Return }
}


