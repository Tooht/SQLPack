<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Write-SQLPackSQLErrorLog {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackConfig "SQLErrorLogConfig.AvailableLevels" } )]
        [ValidateScript( { $_ -in (Get-SQLPackConfig "SQLErrorLogConfig.AvailableLevels") } )]
        [string]$Level ,

        [Parameter(Mandatory = $false)]
        [string]$State
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "Message: $Message"
    Write-Verbose "Level: $Level"
    write-Verbose "State: $State"
        

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Verbose "[$FunctionName] Log message: $logMessage"

    if (-not $Level) {
        $Level = $SQLPackConfigs.SQLErrorLogConfig.DefaultLevel 
        write-Verbose "[$FunctionName] Log level not provided, using default from configuration: $Level" 
    }
    $LevelSimple = $Level.replace("Information", "10").replace("Warning", "13").replace("Error", "19")
    Write-Verbose "[$FunctionName] Log level '$Level' Converted to value '$LevelSimple' ."


    if (-not $State) {
        $State = $SQLPackConfigs.SQLErrorLogConfig.DefaultState 
        Write-Verbose "[$FunctionName] Log State: $State"
    }

    $Query = "RAISERROR ('$Message', $LevelSimple, $State) WITH LOG;"

    Invoke-SQLPackQuery -SQLQuery $Query -ErrorAction SilentlyContinue

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

}