<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Import-SQLPackJson {
    param (
        [Parameter(Mandatory = $true)]
        [string]$FilePath
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] FilePath: $FilePath"

    if (-not(Test-Path -Path $FilePath)) {
        $ret = [SQLPackReturnError]::new("Error" + $FunctionName + "001", "File not found: $FilePath" , $null, $null)
        Write-Verbose "[$FunctionName] Json File $FilePath not found "
    }
    else {
        try {
            $ret = Get-Content -Path $FilePath -Raw | ConvertFrom-Json
            Write-Verbose "[$FunctionName] Json data imported"
        }
        catch {
            $ret = [SQLPackReturnError]::new("Error" + $FunctionName + "002", $_.Exception.Message , $null, $_.Exception)
            Write-Verbose "[$FunctionName] Error: $_.Exception.Message"
        }
    }
    
    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return $ret
}