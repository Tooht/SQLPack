<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Write-SQLPackLogFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackConfig "InUse.LogFileConfig.AvailableLevels" } )]
        [ValidateScript( { $_ -in (Get-SQLPackConfig "InUse.LogFileConfig.AvailableLevels") } )]
        [string]$Level = 'INFO',
        
        [Parameter(Mandatory = $false)]
        [string]$LogPath 
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "Message: $Message"
    Write-Verbose "Level: $Level"
    Write-Verbose "LogPath: $LogPath"

    If (-not $LogPath) {
        Write-Verbose "[$FunctionName] LogPath parameter not provided, using default from configuration"
        if (-not $global:LogFileFullPath) {
            Write-Verbose "[$FunctionName] Script Log File path not defined"

            $NewLogFolderName = $SQLPackConfigs.LogFileConfig.FilePath
            $NewLogFileName = $SQLPackConfigs.LogFileConfig.FileName.replace("{date}", (Get-Date).ToString("yyyyMMddHHmmss"))
            
            $global:LogFileFullPath = Join-Path -Path  $NewLogFolderName -ChildPath $NewLogFileName       
            Write-Verbose "[$FunctionName] Script Log File path set to: $global:LogFileFullPath"
        }

        $LogPath = $global:LogFileFullPath
        Write-Verbose "[$FunctionName] Using log file path: $LogPath"
    }

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $logEntry = "[$timestamp] [$Level] $Message"
    Write-Verbose "[$FunctionName] Log entry to write: $logEntry"
    
    try {
        Add-Content -Path $LogPath -Value $logEntry -ErrorAction Stop
        Write-Verbose "[$FunctionName] Log entry successfully written to $LogPath"
    }
    catch {
        Write-Error "Failed to write to log file: $_"
    }

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"
}