<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Write-SQLPackWindowsEvent {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackConfig "WindowsEventLogConfig.AvailableLevels" } )]
        [ValidateScript( { $_ -in (Get-SQLPackConfig "WindowsEventLogConfig.AvailableLevels") } )]
        [string]$EntryType ,
        
        [Parameter(Mandatory = $false)]
        [int]$EventId = 1000
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "Message: $Message"
    Write-Verbose "EntryType: $EntryType"
    Write-Verbose "EventId: $EventId"
        
    $Source = $SQLPackConfigs.WindowsEventLogConfig.Source
    Write-Verbose "[$FunctionName] Windows Event Log Source: $Source"

    if ($EntryType -eq $null) {
        $EntryType = $SQLPackConfigs.WindowsEventLogConfig.DefaultLevel    
        Write-Verbose "[$FunctionName] SET Windows Event Log Entry Type: $EntryType"
    }

    try {
        Write-EventLog -LogName 'Application' -Source $Source -EntryType $EntryType -Message $Message -EventId $EventId
        Write-Verbose "[$FunctionName] Event log entry written successfully"
    }
    catch {
        Write-Error "Failed to write to Windows Event Log: $_"
    }

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

}