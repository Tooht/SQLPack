<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Write-SQLPackConsole {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackConfig "ConsoleLogConfig.AvailableLevels" } )]
        [ValidateScript( { $_ -in (Get-SQLPackConfig "ConsoleLogConfig.AvailableLevels") } )]
        [string]$Level 

    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "Message: $Message"
    Write-Verbose "Level: $Level"


    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Verbose "[$FunctionName] Log message: $logMessage"

    $hostParams = @{ NoNewline = $false }
    if ($null -ne $SQLPackConfigs.ConsoleLogConfig.Layouts.$Level.ForegroundColor) {
        $hostParams.ForegroundColor = $SQLPackConfigs.ConsoleLogConfig.Layouts.$Level.ForegroundColor 
        Write-Verbose "[$FunctionName] Foreground color for level $Level : $($hostParams.ForegroundColor)" 
    }

    if ($null -ne $SQLPackConfigs.ConsoleLogConfig.Layouts.$Level.BackgroundColor) {
        $hostParams.BackgroundColor = $SQLPackConfigs.ConsoleLogConfig.Layouts.$Level.BackgroundColor 
        Write-Verbose "[$FunctionName] Background color for level $Level : $($hostParams.BackgroundColor)" 
    }
    Write-Verbose "[$FunctionName] Host parameters: $($hostParams | ConvertTo-Json -Depth 5)"

    Write-Host $logMessage @hostParams 

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

}