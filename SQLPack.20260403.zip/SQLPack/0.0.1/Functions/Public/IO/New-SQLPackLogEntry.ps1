<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Write-SQLPackAppLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,
        
        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackConfig "Constants.LogLevels" } )]
        [ValidateScript( { $_ -in (Get-SQLPackConfig "Constants.LogLevels") } )]
        [string]$Level = 'None',
        
        [Parameter(Mandatory = $false)]
        [switch]$ToFile,
        
        [Parameter(Mandatory = $false)]
        [switch]$ToConsole,
        
        [Parameter(Mandatory = $false)]
        [switch]$ToWindowsEvents,
        
        [Parameter(Mandatory = $false)]
        [switch]$ToSQLErrorLog
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"
    
    if ((! $ToFile) -and (! $ToConsole) -and (! $ToWindowsEvents) -and (!$ToSQLErrorLog)) {
        $ToFile = ($SQLPackConfigs.LogFileConfig.ActiveChannel -eq "True")
        $ToConsole = ($SQLPackConfigs.ConsoleLogConfig.ActiveChannel -eq "True")
        $ToWindowsEvents = ($SQLPackConfigs.WindowsEventLogConfig.ActiveChannel -eq "True")
        $ToSQLErrorLog = ($SQLPackConfigs.SQLErrorLogConfig.ActiveChannel -eq "True")
    }
    
    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] Log Message: $Message"
    Write-Verbose "[$FunctionName] Log Level: $Level"   
    Write-Verbose "[$FunctionName] To File: $ToFile"
    Write-Verbose "[$FunctionName] To Console: $ToConsole"
    Write-Verbose "[$FunctionName] To Windows Events: $ToWindowsEvents"
    Write-Verbose "[$FunctionName] To SQL Error Log: $ToSQLErrorLog"

    if ($ToFile) {
        $LogLevel = ($SQLPackConfigs.LogFileConfig.AvailableLevels | Where-Object { $_ -eq $Level })
        if (-not $LogLevel) {
            Write-Verbose "[$FunctionName] Invalid log level '$Level' for file logging."
            $LogLevel = ($SQLPackConfigs.LogFileConfig.DefaultLevel)
        }
        Write-Verbose "[$FunctionName] Log level '$Level' mapped to value '$LogLevel' for file logging."

        Write-SQLPackLogFile -Message $Message -Level $Level
        Write-Verbose "[$FunctionName] Log written to file successfully" 
    }

    if ($ToConsole) {
        $ConsoleLevel = ($SQLPackConfigs.ConsoleLogConfig.AvailableLevels | Where-Object { $_ -eq $Level })
        if (-not $ConsoleLevel) {
            Write-Verbose "[$FunctionName] Invalid console level '$Level' for console logging."
            $ConsoleLevel = ($SQLPackConfigs.ConsoleLogConfig.DefaultLevel)
        }
        Write-Verbose "[$FunctionName] Log level '$Level' mapped to value '$ConsoleLevel' for Console logging."

        Write-SQLPackConsole -Message $Message -Level $ConsoleLevel
        Write-Verbose "[$FunctionName] Log written to console successfully"
    }

    if ($ToWindowsEvents) {
        $WindowsEventLevel = ($SQLPackConfigs.WindowsEventLogConfig.AvailableLevels | Where-Object { $_ -eq $Level })
        if (-not $WindowsEventLevel) {
            Write-Verbose "[$FunctionName] Invalid Windows Event level '$Level' for Windows Event logging."
            $WindowsEventLevel = ($SQLPackConfigs.WindowsEventLogConfig.DefaultLevel)
        }
        Write-Verbose "[$FunctionName] Log level '$Level' mapped to value '$WindowsEventLevel' for Windows Event logging."

        Write-SQLPackWindowsEvent -Message $Message -EntryType $WindowsEventLevel
        Write-Verbose "[$FunctionName] Log written to Windows events successfully"
    }

    if ($ToSQLErrorLog) {
        $SQLErrorLogLevel = ($SQLPackConfigs.SQLErrorLogConfig.AvailableLevels | Where-Object { $_ -eq $Level })
        if (-not $SQLErrorLogLevel) {
            Write-Verbose "[$FunctionName] Invalid Error Log level '$Level' for SQL Error Log logging."
            $SQLErrorLogLevel = ($SQLPackConfigs.SQLErrorLogConfig.DefaultLevel)
        }

        Write-Verbose "[$FunctionName] Log level '$Level' mapped to value '$SQLErrorLogLevel' for Windows Event logging."


        Write-SQLPackSQLErrorLog -Message $Message -Level $SQLErrorLogLevel
        Write-Verbose "[$FunctionName] Log written to SQL Error Log successfully"
    }

    Write-Verbose "[$FunctionName] FUNCTION END"
}