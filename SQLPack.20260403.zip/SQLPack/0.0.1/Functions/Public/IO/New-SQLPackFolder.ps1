<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function New-SQLPackFolder {
    param (      
        [Parameter(Mandatory = $true,
            Position = 0)]
        [string] $FolderPath,

        [Parameter(Mandatory = $false)]
        [ValidateSet("ClearContent", "RenameOld", "RenameNew", "Abort", "Ignore", "Error")]
        [string]$IfExists = "Ignore",

        [Parameter(Mandatory = $false)]
        [string] $RenameSufix = ((Get-Date).ToString("yyyyMMdd.hhmmss")),

        [Parameter(Mandatory = $false)]
        [switch] $Silent
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"
    
    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] FolderPath='$FolderPath'"
    Write-Verbose "[$FunctionName] IfExists='$IfExists'"
    Write-Verbose "[$FunctionName] RenameSufix='$RenameSufix'"
    Write-Verbose "[$FunctionName] Silent='$Silent'"

    If ( -not (Test-Path -Path $FolderPath -PathType Container)) {
        $Obj = New-Item -Path $FolderPath -ItemType Directory  
        Write-Verbose "[$FunctionName] Folder created with success"

        return [SQLPackReturn]::new("Created", "Folder created with success", $Obj )

    }
    else {
        Write-Verbose "[$FunctionName] Folder Already Exists"

        SWITCH ($IfExists) {
            "ClearContent" {
                Get-ChildItem -Path $FolderPath -Recurse | Remove-Item
                Write-Verbose "[$FunctionName] Folder already exists, removed all child itens"

                return [SQLPackReturn]::new("Cleared", "Folder already exists, removed all child itens", (Get-Item -Path $FolderPath))
            }
            "RenameOld" {
                $OldFolder = $FolderPath + $RenameSufix
                $Obj = Rename-Item -Path $FolderPath -NewName $OldFolder
                $Obj = New-Item -Path $FolderPath -ItemType Directory    
                Write-Verbose "[$FunctionName] Folder created with success, existing folder renamed to $OldFolder"

                return [SQLPackReturn]::new("RenamedExisting", "Folder created with success, existing folder renamed to $OldFolder", (Get-Item -Path $FolderPath))
            }
            "RenameNew" {
                $NewName = ($FolderPath + "." + $RenameSufix)
                $Obj = New-Item -Path $NewName -ItemType Directory    
                Write-Verbose "[$FunctionName] Folder created with success, new folder named to $NewName"

                return [SQLPackReturn]::new("RenamedNew", "Folder created with success, new folder named to $NewName", $Obj)
            }
            "Abort" {
                Write-Verbose "[$FunctionName] Folder already exists, creation aborted"
                
                return [SQLPackReturnError]::new("Error"*$FunctionName+"001",  "Folder already exists, creation aborted", $null, (Get-Item -Path $FolderPath)  )
                
            }
            "Ignore" {
                Write-Verbose "[$FunctionName] Folder already exists, creation ignored"
                
                return [SQLPackReturn]::new("Ignored", "Folder already exists, creation ignored", (Get-Item -Path $FolderPath))
            }
            "Error" {
                Write-Verbose "[$FunctionName] Folder aready exists, throw error"
                Write-Error -Message "Folder aready exists" -ErrorId IO1001 -Category "WriteError" -Reason "Folder exists and 'IfExists' parameter set to $IfExists"
                
                return [SQLPackReturnError]::new("Error"*$FunctionName+"002",  "Folder aready exists, throw error", $null, (Get-Item -Path $FolderPath)  )
            }
        }
    }

    Write-Verbose "[$FunctionName] FUNCTION END"

    If (-not $Silent) { return $Return }
}


