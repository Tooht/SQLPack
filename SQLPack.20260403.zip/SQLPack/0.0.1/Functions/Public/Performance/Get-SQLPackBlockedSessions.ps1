﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackBlockedSessions { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    

    $Query = "SELECT session_id, D.name as DatabaseName, request_id, start_time, status, command, user_id, blocking_session_id, wait_type
                            FROM sys.dm_exec_requests R 
                            inner join sys.databases D 
                            On R.database_id=D.database_id 
                            WHERE blocking_session_id <> 0"
        

    Write-Verbose "[$FunctionName] FUNCTION END"

    return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)


}

    