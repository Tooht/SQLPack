﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-DBACommonDatabaseActivity {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [string]$DatabaseName
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"

    if ($DatabaseName) {
        $Filter = "WHERE UPPER(d.name) =UPPER('$DatabaseName')"
        Write-Verbose ("Database Filter: $TypeFilter")
    }

    

    $Query = "SELECT d.name as [database_name], last_user_seek = MAX(last_user_seek), last_user_scan = MAX(last_user_scan), 
        last_user_lookup = MAX(last_user_lookup), last_user_update = MAX(last_user_update) 
        FROM sys.dm_db_index_usage_stats AS i
        JOIN sys.databases AS d ON i.database_id=d.database_id
        $Filter
        GROUP BY d.name ORDER by d.name"
    
    
    $Result = Invoke-DBACommonSQLQuery -Query $Query -InstanceName $InstanceName -InstancePort $InstancePort -QueryTimeOut $QueryTimeOut


    Write-Verbose "[$FunctionName] FUNCTION END"

    return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)
}



