﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackBlockingSessions { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"

    $Query = "select session_id, D.name as DatabaseName, request_id, start_time, status, command, user_id, transaction_id, percent_complete, estimated_completion_time, total_elapsed_time
                            FROM sys.dm_exec_requests R
                                inner join sys.databases D
                                On R.database_id=D.database_id
                            WHERE session_id in ( SELECT blocking_session_id
                            FROM sys.dm_exec_requests
                            WHERE blocking_session_id <> 0 )"
    
    Write-Verbose "[$FunctionName] FUNCTION END"

    return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)


}

    