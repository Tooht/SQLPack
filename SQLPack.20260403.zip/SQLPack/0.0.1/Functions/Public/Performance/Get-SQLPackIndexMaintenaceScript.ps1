<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function  Get-SQLPackIndexMaintenaceScript { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackDatabasesNames } )]
        [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames) } )]
        [string]$DatabaseName,

        [Parameter(Mandatory = $false)]
        [ValidateSet("LastYear", "LastMonth", "LastWeek", "LastDay")]
        [string]$Period,

        [Parameter(Mandatory = $false)]
        [switch] $DatabaseBackups,
        [Parameter(Mandatory = $false)]
        [switch] $LogBackups,
            
        [Parameter(Mandatory = $false)]
        [switch] $RunOffline
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"
    Write-Verbose "[$FunctionName] Period: $Period"
    Write-Verbose "[$FunctionName] DatabaseBackups: $DatabaseBackups"
    Write-Verbose "[$FunctionName] LogBackups: $LogBackups"
    Write-Verbose "[$FunctionName] RunOffline: $RunOffline"


    IF (! $RunOffline) { $Online = " With (ONLINE=ON)" }

    $Query = "SELECT 
CONCAT ('[', dbschemas.[name],'].[' , dbtables.[name] , ']') as TableName,
CONCAT('[' , dbindexes.[name] , ']') As IndexName, 
Cast(  indexstats.avg_fragmentation_in_percent As Decimal(6,2)) as Frag,
case when indexstats.avg_fragmentation_in_percent  > 30 then 
	concat('ALTER INDEX [' , dbindexes.[name] , '] ON [', dbschemas.[name],'].[' , dbtables.[name] , '] REBUILD $Online; ')
else concat('ALTER INDEX [' , dbindexes.[name] , '] ON [', dbschemas.[name],'].[' , dbtables.[name] , '] REORGANIZE $Online; ') end AS CMD
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) AS indexstats
    INNER JOIN sys.tables dbtables ON dbtables.[object_id] = indexstats.[object_id]
    INNER JOIN sys.schemas dbschemas ON dbtables.[schema_id] = dbschemas.[schema_id]
    INNER JOIN sys.indexes AS dbindexes ON dbindexes.[object_id] = indexstats.[object_id] AND indexstats.index_id = dbindexes.index_id
WHERE dbindexes.type=2 and avg_fragmentation_in_percent> 5
ORDER BY indexstats.avg_fragmentation_in_percent DESC;"
  
    
    Write-Host "Beware that this script can take several minutes processing the Database Index Statistics"
    Write-Host "Script is copied to Clipboard so if you want, you can paste the script on SSMS or Azure Data Studio if you prefere"
    
    
    #Execute command to generate script
    $CMDs = Invoke-SQLPackQuery -Query $Query  -DatabaseName $DatabaseName 
  
    #Copy script to clip board
    Set-Clipboard -Value $CMDs.CMD
    
    Write-Verbose "[$FunctionName] FUNCTION END"

    #Display details from script generated
    return (Format-Result -Result ($CMDs) -NotFomated $NotFomated)


}
