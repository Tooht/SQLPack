﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackDeployInfo {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated
    )
     $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"


    $Query = "IF (EXISTS (Select 1 FROM sys.databases WHERE name='DBA_SQL_Toolbox'))
            BEGIN
                IF (EXISTS(SELECT 1 FROM DBA_SQL_Toolbox.sys.tables WHERE NAME='ServerDeployInfo'))
                    SELECT DISTINCT [Config_Type], [Value], [Info] FROM [DBA_SQL_Toolbox].[dbo].[ServerDeployInfo]
	            ELSE
                    SELECT 'Table [ServerDeployInfo] dont exists' as 'ServerDeploy info error'
            END
            ELSE
                SELECT 'Database [DBA_SQL_Toolbox] dont exists' as 'ServerDeploy info error'"
    
    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)
}