﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackDatabaseFiles {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,
            
        [Parameter(Mandatory = $false)]
        [string] $DatabaseName,

        [Parameter(Mandatory = $false)]
        [switch] $LogFiles,

        [Parameter(Mandatory = $false)]
        [switch] $DataFiles
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"
    Write-Verbose "[$FunctionName] LogFiles: $LogFiles"
    Write-Verbose "[$FunctionName] DataFiles: $DataFiles"

 
    if ((-not $LogFiles) -and (-not $DataFiles)) {
        $LogFiles = $true
        $DataFiles = $true
    }

    If ($LogFiles) {
        $Filter = " AND PhysicalFileName LIKE '%.ldf'"
        Write-Verbose "Log files filter applied"
    }

    If ($DataFiles) {
        $Filter = " AND PhysicalFileName NOT LIKE '%.ldf'"
        Write-Verbose "Data files filter applied"
    }

    $

    $Query = "DECLARE @DBInfo TABLE
            ( DatabaseName VARCHAR(100), FileName Varchar(255),PhysicalFileName NVARCHAR(520), FileSizeMB DECIMAL(10, 2),
	            SpaceUsedMB DECIMAL(10, 2), FreeSpaceMB DECIMAL(10, 2), FreeSpacePct VARCHAR(20), MaxSize DECIMAL(10, 2) );

            DECLARE @command NVARCHAR(MAX) = 'USE ?
            SELECT  ''?'' AS DatabaseName,Name as FileName, filename, convert(decimal(12,2),round(size/128.000,2)) as FileSizeMB 
                , convert(decimal(12,2),round(fileproperty(name,''SpaceUsed'')/128.000,2)) as SpaceUsedMB 
                , convert(decimal(12,2),round((size-fileproperty(name,''SpaceUsed''))/128.000,2)) as FreeSpaceMB
                ,CAST(100 * (CAST (((size/128.0 -CAST(FILEPROPERTY(name,''SpaceUsed'' ) AS int)/128.0)/(size/128.0)) AS decimal(4,2))) AS varchar(20)) + ''% free'' AS FreeSpacePct 
	            , convert(decimal(12,2),round(MaxSize/128.000,2)) as  MaxSizeMB
            from dbo.sysfiles;'

            INSERT INTO @DBInfo EXEC sp_MSforeachdb @command;

            SELECT  * FROM @DBInfo WHERE DatabaseName LIKE '%$DatabaseName%' $Filter"

    return (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)

}
