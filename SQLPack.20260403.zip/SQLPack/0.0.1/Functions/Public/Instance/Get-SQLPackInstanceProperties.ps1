﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackInstanceProperties { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"

    $Query = "SELECT 
                SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS [ComputerName]
                ,ISNULL(SERVERPROPERTY('InstanceName'),'Default') AS [Instance]
                ,CASE SERVERPROPERTY('IsClustered')
                            WHEN 1 THEN 'Clustered'
                            WHEN 0 THEN 'Not Clustered'
                            ELSE 'Not applicable'
                        END AS IsClustered
                ,SERVERPROPERTY('Edition') AS [SQL Edition]
                ,SERVERPROPERTY('ProductLevel') AS [ProductLevel]
                ,SERVERPROPERTY('ProductUpdateLevel') AS [ProductUpdateLevel]
                ,SERVERPROPERTY('ProductVersion') AS [ProductVersion]
                ,SERVERPROPERTY('ProductUpdateReference') AS [ProductUpdateReference]
                ,SERVERPROPERTY('ProcessID') AS [ProcessID]
                ,SERVERPROPERTY('Collation') AS [Collation] 
                ,CASE SERVERPROPERTY('IsFullTextInstalled') WHEN 0 THEN 'No' ELSE 'Yes' END AS [IsFullTextInstalled]
                ,CASE SERVERPROPERTY('IsIntegratedSecurityOnly') WHEN 1 THEN 'IntegratedSecurity' ELSE 'MixedSecurity' END AS InSingleUserMode
                ,CASE SERVERPROPERTY('HadrEnabled')
                            WHEN 0 THEN 'Disabled'
                            WHEN 1 THEN 'Enabled'
                            ELSE 'Not applicable'
                        END AS 'AlwaysOn'
                ,CASE SERVERPROPERTY('IsSingleUser') WHEN 0 THEN 'No' ELSE 'Yes' END AS 'SingleUserMode'
                ,SERVERPROPERTY('InstanceDefaultDataPath') AS [InstanceDefaultDataPath]
                ,SERVERPROPERTY('InstanceDefaultLogPath') AS [InstanceDefaultLogPath]
                ,SERVERPROPERTY('BuildClrVersion') AS [Build CLR Version]
                ,CASE SERVERPROPERTY('IsPolybaseInstalled') WHEN 0 THEN 'No' ELSE 'Yes' END AS [IsPolybaseInstalled]" 

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)
}
