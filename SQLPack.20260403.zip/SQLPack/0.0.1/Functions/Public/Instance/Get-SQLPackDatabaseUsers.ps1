<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackDatabaseUsers {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [ValidateSet("SystemDatabases", "UserDatabases")]
        [string]$DatabasesType ,
    
        [Parameter(Mandatory = $false)]
        [switch] $WriteOutput
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] DatabasesType: $DatabasesType"
    Write-Verbose "[$FunctionName] WriteOutput: $WriteOutput"   
    
    switch ($DatabasesType) {
        "SystemDatabases" { $Filter = "WHERE DBName  IN ('master','model','tempdb','msdb','SSISDB')" }
        "UserDatabases" { $Filter = "WHERE DBName NOT IN ('master','model','tempdb','msdb','SSISDB')" }
        Default { $Filter = "WHERE 1=1" }
    }
    Write-Verbose "[$FunctionName] Filter applied: $Filter"
    
    $Query = "CREATE TYPE MytbType AS TABLE(LoginName varchar(200),DBName varchar(200), Allow int)
            GO
            BEGIN TRY
	            DECLARE @T as MytbType, @SQL AS NVARCHAR(MAX)='
	            SELECT S.name,''?'' AS DB , CASE WHEN D.name IS NULL THEN 0 ELSE 1 END AS Allow
	            FROM ?.sys.server_principals S LEFT JOIN ?.sys.database_principals D ON D.name COLLATE DATABASE_DEFAULT =S.name COLLATE DATABASE_DEFAULT
	            WHERE S.name NOT LIKE ''##%'' AND S.[type_desc] IN (''SQL_LOGIN'',''WINDOWS_LOGIN'',''WINDOWS_GROUP'')'

	            INSERT INTO @T EXEC sp_MSforeachdb @SQL

	            UPDATE @T SET Allow=1 WHERE IS_SRVROLEMEMBER('sysadmin', LoginName)=1

	            DECLARE @DBs AS VARCHAR(MAX)
	            SELECT  @DBs=COALESCE(@DBs + '], [', '') +  DBName FROM (SELECT DISTINCT DBName FROM @T $Filter) T

	            SET @SQL=CONCAT('SELECT * FROM (SELECT LoginName,DBName,Allow from @T ) AS source
	            PIVOT (SUM(Allow) FOR DBName IN ([',@DBs,'])) AS pivot_table;')

	            exec sp_executesql @SQL, N'@T as MytbType READONLY', @T
            END TRY
            BEGIN CATCH
            END CATCH

            DROP TYPE MytbType"

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)

}