function Invoke-SQLPackQuery {
    param (
        [parameter(Mandatory = $false)]
        [string] $Instance,
        
        [parameter(Mandatory = $false)]
        [int] $Port,

        [parameter(Mandatory = $false)]
        [string] $Username,
        
        [parameter(Mandatory = $false)]
        [String] $Password,
               
        [Parameter(Mandatory = $false)]
        # [ArgumentCompleter({ Get-SQLPackDatabasesNames } )]
        # [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames) } )]
        [string]$DatabaseName ,
        
        [parameter(Mandatory = $false)]
        [int] $QueryTimeOut,
        
        [parameter(Mandatory = $false)]
        [int] $MaxRecords,

        [Parameter(Mandatory = $true, 
            ValueFromPipeline = $true, 
            Position = 0,
            HelpMessage = "SQL Query to be executed on SQLServer"
        )]       
        [string]$SQLQuery
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"
    
    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] Instance: $Instance"
    Write-Verbose "[$FunctionName] Port: $Port"
    Write-Verbose "[$FunctionName] Username: $Username"
    Write-Verbose "[$FunctionName] Password: $Password"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName" 
    Write-Verbose "[$FunctionName] QueryTimeOut: $QueryTimeOut"
    Write-Verbose "[$FunctionName] MaxRecords: $MaxRecords"
    Write-Verbose "[$FunctionName] SQLQuery: $SQLQuery"


    if (! $SQLPackConfigs) {
        Import-SQLPackConfig
        Write-Verbose "[$FunctionName] Configurations loaded with success"
    }
    
    if ($Instance.Length -eq 0) {
        $Instance = $SQLPackConfigs.SQLServer.Instance
        Write-Verbose "[$FunctionName] Instance is empty. Setting to default value '$Instance' from configuration file  "
    }
    if ($Port -eq 0) {
        $Port = $SQLPackConfigs.SQLServer.Port
        Write-Verbose "[$FunctionName] Port is empty. Setting to default value '$Port' from configuration file  "
    }
    if ($Username.Length -eq 0) {
        $Username = $SQLPackConfigs.SQLServer.Username
        Write-Verbose "[$FunctionName] Username is empty. Setting to default value '$Username' from configuration file  "
    }
    if ($Password.Length -eq 0) {
        $SecurePassword = $SQLPackConfigs.SQLServer.Password
        Write-Verbose "[$FunctionName] Password is empty. Setting to default value from configuration file  "
    }
    else {
        $SecurePassword = ($Password | ConvertTo-SecureString -AsPlainText -Force)
        Write-Verbose "[$FunctionName] Password provided. Using the provided value for the connection  "
    }
    if ($DatabaseName.Length -eq 0) {
        $DatabaseName = $SQLPackConfigs.SQLServer.DatabaseName
        Write-Verbose "[$FunctionName] DatabaseName is empty. Setting to default value '$DatabaseName' from configuration file  "
    }
    if ($QueryTimeOut.Length -eq 0) {
        $QueryTimeOut = $SQLPackConfigs.SQLServer.QueryTimeOut
        Write-Verbose "[$FunctionName] QueryTimeOut is empty. Setting to default value '$QueryTimeOut' from configuration file  "
    }
    if ($MaxRecords.Length -eq 0) {
        $MaxRecords = $SQLPackConfigs.SQLServer.MaxRecords
        Write-Verbose "[$FunctionName] MaxRecords is empty. Setting to default value '$MaxRecords' from configuration file  "
    }

    if ($Port -gt 0) {
        $Instance = "$Instance,$Port" 
        Write-Verbose "[$FunctionName] Port provided. Updated Instance with port: $Instance" 
    }

    $QueryParams = @{
        "ServerInstance" = $Instance
        "Database"       = $DatabaseName
        "QueryTimeOut"   = $QueryTimeOut
    }

    if (($Username.Length -eq 0) -or ($Username -eq "None") -or ($SecurePassword.Length -eq 0) ) {
        Write-Verbose "[$FunctionName] Username and Password not provided. No credentials will be used for the connection. Attempting to connect with Windows Authentication."
    }
    Else {
        
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword)
        $PassW = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)

        $QueryParams.add("Username", $Username)
        $QueryParams.add("Password", $PassW)

        Write-Verbose "[$FunctionName] Credential created with the provided username and password"
    }
    

    Write-Verbose "[$FunctionName] Query parameters prepared for Invoke-Sqlcmd: $($QueryParams | Format-List | Out-String)" 
    
    Write-Verbose "[$FunctionName] Query to run '$SQLQuery'"


    Write-Verbose "[$FunctionName] Verbose Disabled"
    $VerboseState = $VerbosePreference 
    $VerbosePreference = "SilentlyContinue"

    $Result = Invoke-Sqlcmd -Query $SQLQuery @QueryParams 
    
    $VerbosePreference = $VerboseState
    Write-Verbose "[$FunctionName] Verbose Re-Enabled"

    Write-Verbose "[$FunctionName] Query executed. Records: $($Result.Count) "

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return $Result
}
