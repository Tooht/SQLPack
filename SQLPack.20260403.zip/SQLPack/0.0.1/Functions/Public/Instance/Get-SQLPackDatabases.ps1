﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackDatabases { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,
            
            
        [Parameter(Mandatory = $false)]
        [string] $DatabaseName,

        [Parameter(Mandatory = $false)]
        [ValidateSet("SystemDatabases", "UserDatabases")]
        [string] $DatabasesType
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"
    Write-Verbose "[$FunctionName] DatabasesType: $DatabasesType"


    $Filter = " WHERE 1=1 "

    switch ($DatabasesType) {
        "SystemDatabases" {
            $Filter = $Filter + " AND D.name     IN(N'master',N'model',N'tempdb',N'msdb',N'SSISDB') "
            Write-Verbose "System databases filter applied"
        }
        "UserDatabases" {
            $Filter = $Filter + " AND D.name NOT IN(N'master',N'model',N'tempdb',N'msdb',N'SSISDB') "
            Write-Verbose "User databases filter applied"
        }
    }

    if ($DatabaseName) {
        $Filter = $Filter + " AND D.name like '" + ($DatabaseName.Replace("*", "%")) + "'"
        Write-Verbose "DatabaseName filter applied"
    }
    
    $Query = "SELECT D.name as 'DatabaseName', suser_sname( D.owner_sid ) as 'DBOwner', D.create_date as 'CreateDate', D.compatibility_level as 'Comp.Level', D.collation_name as 'Collation', 
                user_access_desc as 'user_access', state_desc as 'Status', recovery_model_desc as 'RecoveryModel'
            FROM master.sys.databases D
            $Filter " 
    
    return (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)

}
