<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Set-SQLPackConfigUserFile {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $Force 
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] Force: $Force"


    $Folder = (get-item $PSScriptRoot )
    Write-Verbose "[$FunctionName] Current folder: $Folder"

    Do {
        $Folder = (get-item $Folder.FullName ).parent
    } While ($Folder.Name -ne "SQLPack") 

    $Folder = (Get-ChildItem -Path $Folder.FullName )|Where-Object {$_.BaseName -ne "SQLPack.Builder"}|Sort-Object -Property Name -Descending|Select-Object -First 1
    Write-Verbose ("[$FunctionName] Main folder:" + $Folder.FullName)

    $ConfigTemplateFile = (Get-ChildItem -Path $Folder.FullName -Recurse -Filter 'configTemplate.json').FullName
    Write-Verbose ("[$FunctionName] Reading config template from " + $ConfigTemplateFile)

    $Global:SQLPackConfigs = Get-Content -Path $ConfigTemplateFile -Raw | ConvertFrom-Json
    Write-Verbose "[$FunctionName] Config template read successfully. Creating config file with default settings from template."

    Write-ConfigUser -ConfigValues $SQLPackConfigs -Force

    Write-Verbose "[$FunctionName] FUNCTION END"

}