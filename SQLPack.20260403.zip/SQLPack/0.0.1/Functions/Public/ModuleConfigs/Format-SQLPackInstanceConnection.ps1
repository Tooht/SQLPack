<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Format-SQLPackInstanceConnection {
    param (
        [parameter(Mandatory = $false)]
        [string] $Instance,
        
        [parameter(Mandatory = $false)]
        [int] $Port,

        [parameter(Mandatory = $false)]
        [string] $Username,
        
        [parameter(Mandatory = $false)]
        [string] $Password,
               
        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackDatabasesNames } )]
        [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames) } )]
        [string]$DatabaseName = "master",
        
        [parameter(Mandatory = $false)]
        [int] $QueryTimeOut,
        
        [parameter(Mandatory = $false)]
        [int] $MaxRecords,

        [Parameter(Mandatory = $false)]
        [switch] $Force ,
        
        [Parameter(Mandatory = $false)]
        [switch] $Silent ,
        

        [Parameter(Mandatory = $false)]
        [ValidateSet("CurrentScript", "UserConfig", "TemplateConfig")]
        [string]$Scope = "CurrentScript"
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] Instance: $Instance"
    Write-Verbose "[$FunctionName] Port: $Port"
    Write-Verbose "[$FunctionName] Username: $Username"
    Write-Verbose "[$FunctionName] Password: $Password"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"
    Write-Verbose "[$FunctionName] QueryTimeOut: $QueryTimeOut"
    Write-Verbose "[$FunctionName] MaxRecords: $MaxRecords"

    $OriginalConfig = $SQLPackConfigs
    
    if ( (! $Instance) -and (! $Port) -and (! $DatabaseName) -and (! $QueryTimeOut) -and (! $MaxRecords) -and (! $Force)) {
        Write-Host "[$FunctionName] No parameters provided to update the SQL Server instance connection settings." -ForegroundColor Yellow
        Write-Host "[$FunctionName] Current Instance name: " -ForegroundColor Green -NoNewline; Write-Host ($SQLPackConfigs.SQLServer.Instance) -ForegroundColor White
        $Answer = Read-Host "[$FunctionName] Do you want to change the SQL Server instance connection settings? (Y/N)"
        if ($Answer -eq "Y") {
            $Instance = Read-Host "[$FunctionName] Please enter the NEW SQL Server instance name (e.g., localhost\SQLEXPRESS):"
            Write-Verbose "[$FunctionName] User entered instance name: $Instance"
        }

        Write-Host "[$FunctionName] Current Port: " -ForegroundColor Green -NoNewline; Write-Host ($SQLPackConfigs.SQLServer.Port) -ForegroundColor White
        $Answer = Read-Host "[$FunctionName] Do you want to change the Port connection settings? (Y/N)"
        if ($Answer -eq "Y") {
            $Port = Read-Host "[$FunctionName] Please enter the NEW Port (e.g., 1433):"
            Write-Verbose "[$FunctionName] User entered Port: $Port"
        }

        Write-Host "[$FunctionName] Current Database name: " -ForegroundColor Green -NoNewline; Write-Host ($SQLPackConfigs.SQLServer.DatabaseName) -ForegroundColor White
        $Answer = Read-Host "[$FunctionName] Do you want to change the DatabaseName connection settings? (Y/N)"
        if ($Answer -eq "Y") {
            Write-Verbose "[$FunctionName] User choose to change the DatabaseName connection settings"
            $DatabaseName = Read-Host "[$FunctionName] Please enter the NEW DatabaseName (e.g., MyDatabase):"
            Write-Verbose "[$FunctionName] User entered DatabaseName: $DatabaseName"
        }

        Write-Host "[$FunctionName] Current QueryTimeOut: " -ForegroundColor Green -NoNewline; Write-Host ($SQLPackConfigs.SQLServer.QueryTimeOut) -ForegroundColor White
        $Answer = Read-Host "[$FunctionName] Do you want to change the QueryTimeOut connection settings? (Y/N)"
        if ($Answer -eq "Y") {
            Write-Verbose "[$FunctionName] User choose to change the QueryTimeOut connection settings"
            $QueryTimeOut = Read-Host "[$FunctionName] Please enter the NEW QueryTimeOut (e.g., 0):"
            Write-Verbose "[$FunctionName] User entered QueryTimeOut: $QueryTimeOut"
        }

        Write-Host "[$FunctionName] Current MaxRecords: " -ForegroundColor Green -NoNewline; Write-Host ($SQLPackConfigs.SQLServer.MaxRecords) -ForegroundColor White
        $Answer = Read-Host "[$FunctionName] Do you want to change the MaxRecords connection settings? (Y/N)"
        if ($Answer -eq "Y") {
            Write-Verbose "[$FunctionName] User choose to change the MaxRecords connection settings"
            $MaxRecords = Read-Host "[$FunctionName] Please enter the NEW MaxRecords (e.g., 1000):"
            Write-Verbose "[$FunctionName] User entered MaxRecords: $MaxRecords"
        }
    }


    if ($null -ne $Instance) {
        $SQLPackConfigs.SQLServer.Instance = $Instance 
        Write-Verbose "[$FunctionName] Updated Instance in SQLPackConfigs: $($SQLPackConfigs.SQLServer.Instance)" 
        $MSG = "$MSG SQLPackConfigs: $($SQLPackConfigs.SQLServer.Instance);" 
    }
    if ($null -ne $Port) {
        $SQLPackConfigs.SQLServer.Port = $Port 
        Write-Verbose "[$FunctionName] Updated Port in SQLPackConfigs: $($SQLPackConfigs.SQLServer.Port)"   
        $MSG = "$MSG SQLPackConfigs: $($SQLPackConfigs.SQLServer.Port);"
    }
    if($null -ne $Username) {
        $SQLPackConfigs.SQLServer.Username = $Username 
        Write-Verbose "[$FunctionName] Updated Username in SQLPackConfigs: $($SQLPackConfigs.SQLServer.Username)" 
        $MSG = "$MSG SQLPackConfigs: $($SQLPackConfigs.SQLServer.Username);"
    }
    if ($Password.Length -gt 0) {
        
        $SQLPackConfigs.SQLServer.Password = ($Password | ConvertTo-SecureString -AsPlainText -Force)
        Write-Verbose "[$FunctionName] Updated Password in SQLPackConfigs: ********" 
        $MSG = "$MSG SQLPackConfigs: ********;"
    }
    if ($null -ne $DatabaseName) {
        $SQLPackConfigs.SQLServer.DatabaseName = $DatabaseName 
        Write-Verbose "[$FunctionName] Updated DatabaseName in SQLPackConfigs: $($SQLPackConfigs.SQLServer.DatabaseName)" 
        $MSG = "$MSG SQLPackConfigs: $($SQLPackConfigs.SQLServer.DatabaseName);"
    }
    if ($null -ne $QueryTimeOut) {
        $SQLPackConfigs.SQLServer.QueryTimeOut = $QueryTimeOut 
        Write-Verbose "[$FunctionName] Updated QueryTimeOut in SQLPackConfigs: $($SQLPackConfigs.SQLServer.QueryTimeOut)" 
        $MSG = "$MSG SQLPackConfigs: $($SQLPackConfigs.SQLServer.QueryTimeOut);"
    }
    if ($null -ne $MaxRecords) {
        $SQLPackConfigs.SQLServer.MaxRecords = $MaxRecords
        Write-Verbose "[$FunctionName] Updated MaxRecords in SQLPackConfigs: $($SQLPackConfigs.SQLServer.MaxRecords)" 
        $MSG = "$MSG SQLPackConfigs: $($SQLPackConfigs.SQLServer.MaxRecords);"
    }  

    Write-Verbose "[$FunctionName] Testing the new connection settings by executing the test query defined in SQLPackConfigs.SQLServer.TestConnectionQuery"
    $RTest = Invoke-SQLPackQuery -SQLQuery ( $SQLPackConfigs.SQLServer.TestConnectionQuery)  -ErrorAction SilentlyContinue

    If ($null -ne $RTest) {
        Write-Verbose "[$FunctionName] Connection test successful with the new settings."
    }
    else {
        Write-Error "[$FunctionName] Connection test failed with the new settings. Reverting to original settings."
        $SQLPackConfigs = $OriginalConfig
        
        return [SQLPackReturnError]::new("Error" + $FunctionName + "001", "Connection test failed with the new settings. Original settings have been restored.", $OriginalConfig.SQLServer, $null)
    }

    switch ($Scope) {
        "UserConfig" {
            Write-ConfigUser -ConfigValues $SQLPackConfigs
            Write-Verbose "[$FunctionName] Saved the new settings to User Config file"
            $Rsult = "UpdatedUserConfig"
        }
        "TemplateConfig" {
            Write-ConfigTemplate -ConfigValues $SQLPackConfigs
            Write-Verbose "[$FunctionName] Saved the new settings to Template Config file"
            $Rsult = "UpdatedTemplateConfig"
        }
        Default {
            Write-Verbose "[$FunctionName] New settings applied for the current script execution only"
            $Rsult = "UpdatedCurrentScriptConfig"
        }
    }

    if (! $Silent) { return [SQLPackReturn]::new($Rsult, $MSG, $SQLPackConfigs.SQLServer) }

    Write-Verbose "[$FunctionName] FUNCTION END"


}