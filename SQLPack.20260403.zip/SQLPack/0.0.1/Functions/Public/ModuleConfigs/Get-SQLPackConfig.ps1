<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackConfig {
    [CmdletBinding()]
    param(
        [Parameter( Mandatory = $false)]
        [string]$ConfigPath
    )
     $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] ConfigPath: $ConfigPath"

    
    if (-not $SQLPackConfigs) {
        Write-Verbose "[$FunctionName] Import SQLPack Configurations"
        Import-SQLPackConfig -Force 
    }

    $Result = $SQLPackConfigs

    if ($ConfigPath) {
        Write-Verbose "[$FunctionName] Serche for node $ConfigPath"
    
        foreach ($Folder in $ConfigPath.Split(".")) {
            Write-Verbose "[$FunctionName] Filter for folder $Folder "
            $Result = $Result.$Folder
        }
        Write-Verbose "[$FunctionName] Retrieved value: $SQLPackConfigs"
    }

    Write-Verbose "[$FunctionName] FUNCTION END"
        
    return $Result
}


