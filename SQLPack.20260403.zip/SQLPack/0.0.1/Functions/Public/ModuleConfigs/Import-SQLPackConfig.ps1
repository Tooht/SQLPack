<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Import-SQLPackConfig {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [switch] $Force 
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] Force: $Force"
    
    if (-not $Global:SQLPackConfigs -or $Force) {
        Write-Verbose "[$FunctionName] Loading SQLPack Configurations"

        $ConfigFilePath = "$ENV:Userprofile\AppData\Local\SQLPack\Configs.json"
        Write-Verbose "[$FunctionName] Config file path: $ConfigFilePath"

        if (-not (Test-Path -Path $ConfigFilePath)) {
            Write-Verbose ( "[$FunctionName] ConfigFile not found on $ConfigFilePath" )
            Set-SQLPackConfigUserFile -Force
            Write-Verbose ( "[$FunctionName] Config file created at $ConfigFilePath with default settings from template" )
        }

        try {
            $Global:SQLPackConfigs = Get-Content -Path $ConfigFilePath -Raw | ConvertFrom-Json
            Write-Verbose "[$FunctionName] Configurations loaded successfully"
            $return = [SQLPackReturn]::new("Imported"  , "Configurations imported successfully", $Global:SQLPackConfigs)
        }
        catch {
            $return = [SQLPackReturnError]::new("Error" + $FunctionName + "001", $_.Exception.Message , $null, $_.Exception)
            Write-Error $_.Exception.Message -ErrorId "Error" + $FunctionName + "001" -Category "ReadError" -TargetObject $ConfigFilePath
        }
    }
    else {
        Write-Verbose "[$FunctionName] Configurations already loaded. Use -Force to reload them."
        $return = [SQLPackReturn]::new("AlreadyLoaded"  , "Configurations already loaded. Use -Force to reload them.", $Global:SQLPackConfigs)
    }    
    Write-Verbose "[$FunctionName] FUNCTION END"

    return $return
    
}


