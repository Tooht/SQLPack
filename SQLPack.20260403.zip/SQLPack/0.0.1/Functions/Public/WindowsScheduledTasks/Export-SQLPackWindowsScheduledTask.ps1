<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Export-SQLPackWindowsScheduledTask {
    param (      
        [Parameter(Mandatory = $false)]
        [string] $TaskName,

        [Parameter(Mandatory = $false)]
        [string] $DestinationFolder = "C:\Temp\WindowsScheduledTasks"      
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] TaskName='$TaskName'"
    Write-Verbose "[$FunctionName] DestinationFolder='$DestinationFolder'"

    New-SQLPackFolder -FolderPath $DestinationFolder -IfExists Ignore -Silent

    $DT = (Get-Date).ToString("yyyyMMdd.hhmmss") 
    Write-Verbose "[$FunctionName] DT: $DT"

    $iCount=0
    Get-ScheduledTask |WHERE-Object {$_.TaskName -like $TaskName} | ForEach-Object {
        $OutputFile = Join-Path -Path $DestinationFolder -ChildPath ($_.TaskName + ".$DT.xml")
        Write-Verbose ("[$FunctionName] Exporting '" + $_.TaskName + "' to '$OutputFile'")
        
        $_ | Export-ScheduledTask | out-file  $OutputFile  
        Write-Verbose ("[$FunctionName] Task exported with success")
        $iCount=iCount+1
    }

    Write-Verbose "[$FunctionName] $iCount Tasks exported"
    Write-Verbose "[$FunctionName] FUNCTION END"
}