<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Import-SQLPackWindowsScheduledTask {
    param (      
        [Parameter(Mandatory = $true)]
        [string] $SourceFolder ,

        [Parameter(Mandatory = $true)]
        [string] $FileName  ,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Override", "Abort", "Ignore", "Error")]
        [string]$IfExists    
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] SourceFolder='$SourceFolder'"
    Write-Verbose "[$FunctionName] FileName='$FileName'"
    Write-Verbose "[$FunctionName] IfExists='$IfExists'"

    if (-not(Test-Path $SourceFolder)) {
        Write-Verbose "[$FunctionName] Source folder '$SourceFolder' dont exists"
        return [SQLPackReturnError]::new("Error" + $FunctionName + "001", "Source folder '$SourceFolder' dont exists" , $null, $null)   
    }

    $Tasks = ""
    $iCount = 0
    Get-ChildItem -Path $SourceFolder -Filter $FileName | ForEach-Object {
        IF (Get-ScheduledTask -TaskName $_.BaseName -ErrorAction SilentlyContinue) {
            Write-Verbose "[$FunctionName] Task '$_.BaseName' already exists"
            Switch ($IfExists) {
                "Override" {
                    $R = Register-ScheduledTask -xml (Get-Content $_.FullName | Out-String)  -TaskName $_.BaseName -CimSession . -Force
                    $Tasks += $_.BaseName + ";"
                    Write-Verbose "Task $_.TaskName Imported with success, overrided existing task" 
                    return [SQLPackReturn]::new("Overrided", "Task '$_.BaseName' already exists, imported with success, overrided existing task" , $null)
                }
                "Abort" {
                    Write-Verbose "[$FunctionName] Task '$_.BaseName' already exists and IfExists set to '$IfExists'"
                    return [SQLPackReturnError]::new("Error" + $FunctionName + "002", "Task '$_.BaseName' already exists" , $null, $null)   
                }
                "Ignore" {
                    Write-Verbose "Task $_.TaskName NOT Imported" 
                    return [SQLPackReturn]::new("Ignored", "Task '$_.BaseName' already exists, task ignored" , $null)
                }
                "Error" {
                    Write-Verbose "[$FunctionName] Task '$_.BaseName' already exists, throw error"
                    Write-Error -Message "Task '$_.BaseName' already exists" -ErrorId IO0002 -Category "WriteError" -Reason "Task '$_.BaseName' already exists"
                return [SQLPackReturnError]::new("Error" + $FunctionName + "003", "Task '$_.BaseName' already exists, throw error" , $null, $null)  
                }
            }
        }
        else {
              
            $R = Register-ScheduledTask -xml (Get-Content $_.FullName | Out-String)  -TaskName $_.BaseName -CimSession .
            $Tasks += $_.BaseName + "; "
            
            Write-Verbose "Task $_.TaskName Imported with success" 
           
        }
        $iCount += 1

    }

    Write-Verbose "[$FunctionName] $iCount Tasks Imported"

    Write-Verbose "[$FunctionName] FUNCTION END"

    $return= [SQLPackReturn]::new("Completed", "Imported Tasks: $Tasks ", $null)
    return $return
}