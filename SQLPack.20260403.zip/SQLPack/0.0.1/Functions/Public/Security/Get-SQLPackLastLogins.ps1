<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackLastLogins {
    param (      
        [Parameter(Mandatory=$false)]
            [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
            [string]$LoginName
    )
     $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] LoginName: $LoginName"

    $QueryCheckLoginAudit = "
DECLARE @AuditLevel int
EXEC master..xp_instance_regread 
    @rootkey='HKEY_LOCAL_MACHINE',
    @key='SOFTWARE\Microsoft\MSSQLServer\MSSQLServer',
    @value_name='AuditLevel',
    @value=@AuditLevel output
SELECT @AuditLevel AS AuditLevelCode,
	CASE @AuditLevel 
		WHEN 0 then 'None'
		WHEN 1 then 'Successful Logins Only'
		WHEN 2 then 'Failed Logins Only'
		WHEN 3 then 'Both Failed and Successful Logins'
		ELSE ''
	end as AuditLevelDesc											
"
    Write-Verbose "[$FunctionName] Executing query: $QueryCheckLoginAudit"

    $CheckAuditLogin = (Invoke-SQLPackQuery -SQLQuery $QueryCheckLoginAudit )

    IF($CheckAuditLogin.AuditLevelCode -ne 2 )
    {
       $Return = @{
            Success = $false
            Message = "Login Auditing '"+ $CheckAuditLogin.AuditLevelDesc +"' and need to be 'Both Failed and Successful Logins'  "
            Object  = $null
        } 
    }
    else {
        $Query="
            DECLARE @Arquivos_Log TABLE ( [idLog] INT, [dtLog] NVARCHAR(30) COLLATE SQL_Latin1_General_CP1_CI_AI, [tamanhoLog] INT )
            DECLARE @UltimoLogin TABLE  ([User] VARCHAR(128) COLLATE SQL_Latin1_General_CP1_CI_AI NOT NULL, LogDate DATETIME NOT NULL)
            DECLARE @Dados TABLE ([LogDate] DATETIME, [ProcessInfo] NVARCHAR(50) COLLATE SQL_Latin1_General_CP1_CI_AI, 
                [Text] NVARCHAR(MAX) COLLATE SQL_Latin1_General_CP1_CI_AI, [User] AS (SUBSTRING(REPLACE([Text], 
                'Login succeeded for user ''', ''), 1, CHARINDEX('''', REPLACE([Text], 'Login succeeded for user ''', '')) - 1)))
            DECLARE @LastLogin TABLE (Username VARCHAR(128) COLLATE SQL_Latin1_General_CP1_CI_AI NOT NULL, CreateDate DATETIME,
                LastLogin DATETIME NULL, DaysSinceLastLogin AS (DATEDIFF(DAY, ISNULL(LastLogin, CreateDate), CONVERT(DATE, GETDATE()))) )
            DECLARE @Contador INT = 0, @Total INT = (SELECT COUNT(*) FROM @Arquivos_Log)

            INSERT INTO @Arquivos_Log
            EXEC sys.sp_enumerrorlogs
            
            WHILE(@Contador < @Total)
            BEGIN
                INSERT INTO @Dados (LogDate, ProcessInfo, [Text]) 
                EXEC master.dbo.xp_readerrorlog @Contador, 1, N'Login succeeded for user', NULL, NULL, NULL
                SET @Contador += 1
            END

            INSERT INTO @UltimoLogin
            SELECT [User], MAX(LogDate) AS LogDate
            FROM @Dados
            GROUP BY [User]

            INSERT INTO @LastLogin (Username, CreateDate)
            SELECT [name],create_date
            FROM sys.server_principals A
                LEFT JOIN @LastLogin B ON A.[name] COLLATE SQL_Latin1_General_CP1_CI_AI = B.Username
            WHERE is_fixed_role = 0
                AND [name] NOT LIKE 'NT %'
                AND [name] NOT LIKE '##%'
                AND B.Username IS NULL
                AND A.[type] IN ('S', 'U')

            UPDATE A
            SET A.LastLogin = B.LogDate
            FROM @LastLogin A
                JOIN @UltimoLogin B ON A.Username = B.[User]
            WHERE ISNULL(A.LastLogin, '1900-01-01') <> B.LogDate

            SELECT * 
            FROM @LastLogin
        "

       $Return =  (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)
        } 

    Write-Verbose "[$FunctionName] FUNCTION END"

    return $Return
}

