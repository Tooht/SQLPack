﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackAlwaysOnHealth {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"

    $Query = "select R.replica_server_name ServerName, 
                RCS.database_name DatabaseName, 
                RCS.is_failover_ready FailoverReady,
                RCS.is_database_joined DatabaseJoined, 
                R.failover_mode_desc FailoverMode,
                RS.is_primary_replica PrimaryReplica, 
                RS.synchronization_state_desc SyncState,
                RS.synchronization_health_desc SyncHealth, 
                RS.database_state_desc DatabaseState
            FROM sys.dm_hadr_database_replica_states RS
            INNER JOIN sys.availability_replicas R 
                ON R.replica_id=RS.replica_id
            INNER JOIN sys.dm_hadr_database_replica_cluster_states  RCS 
                On RS.group_database_id=RCS.group_database_id and RS.replica_id=RCS.replica_id
            ORDER BY 6 DESC"
    
    Write-Verbose "[$FunctionName] FUNCTION FINISHED"
    
    return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)

}
