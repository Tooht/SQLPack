﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackCMDBFileContent { 
        param (
                [Parameter(Mandatory = $false)]
                [switch] $NotFomated,

                [Parameter(Mandatory = $false)]
                [string]$FileLocation = "C:\cmdb"
        )
        $FunctionName = (Get-FunctionName)
        Write-Verbose "[$FunctionName] FUNCTION START"

        Write-Verbose "[$FunctionName] Parameters received: "
        Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
        Write-Verbose "[$FunctionName] FileLocation: $FileLocation"

        $DIFF = (Get-Content -Path "$FileLocation\cmdb_sql_lastbackup_diff.txt")
        $FULL = (Get-Content -Path "$FileLocation\cmdb_sql_lastbackup_full.txt")

        $yourData = @(
                @{File = "cmdb_sql_lastbackup_diff"; Date = "$DIFF" },
                @{File = "cmdb_sql_lastbackup_full"; Date = "$FULL" }) | ForEach-Object { New-Object object | Add-Member -NotePropertyMembers $_ -PassThru }

        Write-Verbose "[$FunctionName] FUNCTION FINISHED"

        return (Format-Result -Result $yourData -NotFomated $NotFomated)
}