﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackBackupsLastRuns { 
        param (
                [Parameter(Mandatory = $false)]
                [switch] $NotFomated,

                [Parameter(Mandatory = $false)]
                [ArgumentCompleter( { Get-SQLPackDatabasesNames } )]
                [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames) } )]
                [string]$DatabaseName
        )
        $FunctionName = (Get-FunctionName)
        Write-Verbose "[$FunctionName] FUNCTION START"

        Write-Verbose "[$FunctionName] Parameters received: "
        Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
        Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"


        If ($DatabaseName) {
                $DatabaseFilter = " And bs.database_name='$DatabaseName' "
                Write-Verbose "[$FunctionName] Database filter applied"
        }

        $Query = " SELECT
        UPPER(a.Name) AS DatabaseName ,
        a.state_desc as State,
        CONVERT(SYSNAME, DATABASEPROPERTYEX(a.name, 'Recovery')) RecoveryModel ,
        COALESCE(( SELECT   CONVERT(VARCHAR(20), MAX(backup_finish_date), 120)
                    FROM     msdb.dbo.backupset
                    WHERE    database_name = a.name
                            AND type in('d' ,'D')
                            AND is_copy_only = '0'
                    ), 'No Full') AS 'Full' ,
        COALESCE(( SELECT   CONVERT(VARCHAR(20), MAX(backup_finish_date), 120)
                    FROM     msdb.dbo.backupset
                    WHERE    database_name = a.name
                            AND type in ('i','I')
                            AND is_copy_only = '0'
                    ), 'No Diff') AS 'Diff' ,
        COALESCE(( SELECT   CONVERT(VARCHAR(20), MAX(backup_finish_date), 120)
                    FROM     msdb.dbo.backupset
                    WHERE    database_name = a.name
                            AND type in ('l', 'L')
                    ), 'No Log') AS 'LastLog' ,
        COALESCE(( SELECT   CONVERT(VARCHAR(20), backup_finish_date, 120)
                    FROM     ( SELECT    ROW_NUMBER() OVER ( ORDER BY backup_finish_date DESC ) AS 'rownum' ,
                                        backup_finish_date
                                FROM      msdb.dbo.backupset
                                WHERE     database_name = a.name
                                        AND type in ('L', 'l')
                            ) withrownum
                    WHERE    rownum = 2
                    ), 'No Log') AS 'LastLog2'
        FROM sys.databases a
        LEFT OUTER JOIN msdb.dbo.backupset b ON b.database_name = a.name
        WHERE   a.name <> 'tempdb'
        AND a.state_desc = 'online' 
        $DatabaseFilter
        GROUP BY a.Name ,
        a.compatibility_level,
        a.state_desc"
    
        Write-Verbose "[$FunctionName] FUNCTION FINISHED"

        return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)
}