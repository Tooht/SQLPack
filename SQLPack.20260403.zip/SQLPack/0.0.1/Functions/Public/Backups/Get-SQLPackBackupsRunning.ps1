﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackBackupsRunning { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [int]$MaxRecords = 100
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] MaxRecords: $MaxRecords" 

    $Query = "SELECT TOP ($MaxRecords) D.name,
                    r.session_id,
                    r.command,
                    CONVERT(NUMERIC(6, 2), r.percent_complete) AS [Percent Complete],
	                r.Start_Time,
                    CONVERT(VARCHAR(20), DATEADD(ms, r.estimated_completion_time, GETDATE()), 20) AS [ETA Completion Time],
                    CAST( DATEADD(MILLISECOND,r.total_elapsed_time, CAST('1900-01-01 00:00:00.000' AS DATETIME)) AS TIME(0)) AS [Time Running],
                    CAST( DATEADD(MILLISECOND,r.estimated_completion_time, CAST('1900-01-01 00:00:00.000' AS DATETIME)) AS TIME(0)) AS [Time Remaning],
                    CONVERT(NUMERIC(10, 2), r.total_elapsed_time / 1000.0 / 60.0) AS [Elapsed Min],
                    CONVERT(NUMERIC(10, 2), r.estimated_completion_time / 1000.0 / 60.0) AS [ETA Min],
                    CONVERT(NUMERIC(10, 2), r.estimated_completion_time / 1000.0 / 60.0 / 60.0) AS [ETA Hours],
                    CONVERT(VARCHAR(1000),
                (
	                SELECT SUBSTRING(text, r.statement_start_offset / 2,
														                CASE
															                WHEN r.statement_end_offset = -1
															                THEN 1000
															                ELSE(r.statement_end_offset - r.statement_start_offset) / 2
														                END)
                    FROM sys.dm_exec_sql_text(sql_handle)
                )) AS [SQL]
                FROM sys.dm_exec_requests r
                    INNER JOIN sys.databases D ON r.database_id = D.database_id
                WHERE command IN('RESTORE DATABASE','RESTORE LOG', 'BACKUP DATABASE', 'BACKUP LOG')"

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)
    
}

