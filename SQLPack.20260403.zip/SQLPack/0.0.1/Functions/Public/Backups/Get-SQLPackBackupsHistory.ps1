﻿<#
.SYNOPSIS
Execute a SQL Query on defined SQL instance 

.DESCRIPTION
By defaul the defined sql instance is localhost, but you can set a new instance to be used in main menu option 99
All Queries are saved on clipboard in order to use on SSMS or other app

.PARAMETER OutputFolderPath
Devine the folder where log file should be save
Default value "C:\Temp"

.INPUTS
None. 

.OUTPUTS
None.

.EXAMPLE
Set-LogFile -OutputFileName "App.[TIMESTAMP].log"
Simple log file with a name like "App.20260325.092622.log"

.LINK
Write-SQLPackLogFile
#>
function Get-SQLPackBackupsHistory { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [int]$MaxRecords = 100,

        [Parameter(Mandatory = $false)]
        [ArgumentCompleter({ Get-SQLPackDatabasesNames -NotFomated } )]
        [ValidateScript( { $_ -in (Get-SQLPackDatabasesNames -NotFomated) } )]
        [string]$DatabaseName,

        [Parameter(Mandatory = $false)]
        [ValidateSet("LastYear", "LastMonth", "LastWeek", "LastDay")]
        [string]$Period,

        [Parameter(Mandatory = $false)]
        [switch] $DatabaseBackups,
        [Parameter(Mandatory = $false)]
        [switch] $LogBackups,
            
        [Parameter(Mandatory = $false)]
        [switch] $IncludeCopyOnly
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] MaxRecords: $MaxRecords"
    Write-Verbose "[$FunctionName] DatabaseName: $DatabaseName"
    Write-Verbose "[$FunctionName] Period: $Period"
    Write-Verbose "[$FunctionName] DatabaseBackups: $DatabaseBackups"
    Write-Verbose "[$FunctionName] LogBackups: $LogBackups"
    Write-Verbose "[$FunctionName] IncludeCopyOnly: $IncludeCopyOnly"


    Switch ($Period) {
        "LastYear" { $PeriodFilter = " backup_start_date > DATEADD(Year,-1,GETDATE()) " }
        "LastMonth" { $PeriodFilter = " backup_start_date > DATEADD(Month,-1,GETDATE()) " }
        "LastWeek" { $PeriodFilter = " backup_start_date > DATEADD(Week,-1,GETDATE()) " }
        "LastDay" { $PeriodFilter = " backup_start_date > DATEADD(Day,-1,GETDATE()) " }
        Default { $PeriodFilter = " backup_start_date > DATEADD(Month,-1,GETDATE()) " }
    }
    Write-Verbose "[$FunctionName] Period filter applied: $PeriodFilter"

    if ((-not $DatabaseBackups) -and (-not $LogBackups)) {
        $DatabaseBackups = $true
        $LogBackups = $true
    }

    $TypeFilter = "'X'"
    if ($DatabaseBackups) {
        $TypeFilter += ",'D','I','F'" 
        Write-Verbose "[$FunctionName] Include Database Backup types in the result"
    }
    if ($LogBackups) {
        $TypeFilter += ",'L'" 
        Write-Verbose "[$FunctionName] Include Log Backup types in the result"
    }

    $TypeFilter = " AND bs.type in ($TypeFilter) "
    Write-Verbose "[$FunctionName] Backup type filter applied"

    if (! $IncludeCopyOnly) {
        $CopyOnlyFilter = " AND is_copy_only=0 " 
        Write-Verbose "[$FunctionName] Exclude Copy Only backups filter applied"
    }

    If ($DatabaseName -ne '') {
        $DatabaseFilter = " AND bs.database_name='$DatabaseName'" 
        Write-Verbose "[$FunctionName] Database filter applied"
    }

    $Query = "SELECT TOP ($MaxRecords) DatabaseName = bs.database_name
            , RecoveryModel = bs.recovery_model
            , BackupStartDate = bs.backup_start_date
            , Duration = datediff(second, bs.backup_start_date,bs.backup_finish_date)
            , CopyOnly = is_copy_only
            , CompressedSize = bs.compressed_backup_size
            , BackupType = CASE bs.type 
                WHEN 'D' THEN 'Database' 
                WHEN 'I' THEN 'Database' 
                WHEN 'L' THEN 'Log' 
                ELSE '[unknown]' END
            , BackupSetName = bs.name
            , ServerName = bs.server_name
            , LogicalDeviceName = bmf.logical_device_name
            , PhysicalDeviceName = bmf.physical_device_name
            , BackupFinishDate = bs.backup_finish_date
            , ExpirationDate = bs.expiration_date
            FROM msdb.dbo.backupset bs
                INNER JOIN msdb.dbo.backupmediafamily bmf
                ON [bs].[media_set_id] = [bmf].[media_set_id]
            WHERE $PeriodFilter $TypeFilter $CopyOnlyFilter  $DatabaseFilter
            ORDER BY bs.backup_start_date DESC;"

    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return (Format-Result -Result (Invoke-SQLPackQuery -SQLQuery $Query) -NotFomated $NotFomated)
}
