<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackAgentJobRunning { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,
            
        [Parameter(Mandatory = $false)]
        [string]$JobName
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] JobName: $JobName"


    if ($JobName) {
        $Filter = $Filter + " AND j.name LIKE '" + $JobName.Replace("*", "%") + "' "
        Write-Verbose "JobName filter applied"
    }

    $query = "SELECT ja.job_id, j.name AS job_name, ja.start_execution_date,      
                            ISNULL(last_executed_step_id,0)+1 AS current_executed_step_id, js.step_name
                        FROM msdb.dbo.sysjobactivity ja 
                        LEFT JOIN msdb.dbo.sysjobhistory jh ON ja.job_history_id = jh.instance_id
                        JOIN msdb.dbo.sysjobs j ON ja.job_id = j.job_id
                        JOIN msdb.dbo.sysjobsteps js ON ja.job_id = js.job_id
                            AND ISNULL(ja.last_executed_step_id,0)+1 = js.step_id
                        WHERE ja.session_id = ( SELECT TOP 1 session_id FROM msdb.dbo.syssessions ORDER BY agent_start_date DESC  )
                        AND start_execution_date is not null
                        AND stop_execution_date is null
                        $Filter;"
 
    Write-Verbose "[$FunctionName] FUNCTION FINISHED"

    return (Format-Result (Invoke-SQLPackQuery -SQLQuery $Query) $NotFomated)
}