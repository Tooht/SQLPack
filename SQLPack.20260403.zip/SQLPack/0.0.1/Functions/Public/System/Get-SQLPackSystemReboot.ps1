﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
Function Get-SQLPackSystemReboot {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory=$false)]
            [int]$MaxRecords=20,

        [Parameter(Mandatory = $false)]
        [ValidateSet("LastYear", "LastMonth", "LastWeek", "LastDay")]
        [string]$Period

    ) 
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] MaxRecords: $MaxRecords"
    Write-Verbose "[$FunctionName] Period: $Period"
    

    $Computer = $env:COMPUTERNAME.ToUpper()

    Write-Verbose "[$FunctionName] Comupter Name:$Computer"

    switch ($Period) {
        "LastYear" {$StartTime = (Get-Date).AddYears(-1); break}
        "LastMonth" {$StartTime = (Get-Date).AddMonths(-1); break}
        "LastWeek" {$StartTime = (Get-Date).AddDays(-7); break}
        "LastDay" {$StartTime = (Get-Date).AddDays(-1); break}
        DEFAULT {$StartTime = (Get-Date).AddMonths(-1); break}
    }
    Write-Verbose "[$FunctionName] Start time: $StartTime"


    $EventList = Get-WinEvent -FilterHashtable @{
        Logname   = 'system'
        Id        = '1074', '6008', '6005'
        StartTime = $StartTime
    } -MaxEvents $MaxRecords -ErrorAction SilentlyContinue
    Write-Verbose ("[$FunctionName] Event list loaded with " + $EventList.Count + " Records")

    #Eventviewer EventID codes
    #https://www.shellhacks.com/windows-shutdown-reboot-event-ids-get-logs/

    #Validate each event, if is a reboot event than configure it on $EventList
    $Result += foreach ($E in $EventList) {
        if ($E.Id -eq 1074) {
            [PSCustomObject]@{
                TimeStamp    = $E.TimeCreated
                ComputerName = $Computer
                UserName     = $E.Properties.value[6]
                ShutdownType = $E.Properties.value[4]
            }
        }
 
        if ($E.Id -eq 6008) {
            [PSCustomObject]@{
                TimeStamp    = $E.TimeCreated
                ComputerName = $Computer
                UserName     = $null
                ShutdownType = 'unexpected shutdown'
            }
        }
        if ($E.Id -eq 6005) {
            [PSCustomObject]@{
                TimeStamp    = $E.TimeCreated
                ComputerName = $Computer
                UserName     = $null
                ShutdownType = 'EventViewer Start'
            }
        }
    }

    Write-Verbose "[$FunctionName] FUNCTION END"
        
    return (Format-Result $Result $NotFomated)
}
