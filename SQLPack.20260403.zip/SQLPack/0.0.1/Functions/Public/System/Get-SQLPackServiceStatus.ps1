﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackServiceStatus {
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated,

        [Parameter(Mandatory = $false)]
        [string]$ServiceName ,
            
        [Parameter(Mandatory = $false)]
        [string]$DisplayName ,
            
        [Parameter(Mandatory = $false)]
        [ValidateSet("Running", "paused", "starting", "pausing", "stopping", "stopped")]
        [string]$State,

        [Parameter(Mandatory = $false)]
        [ValidateSet("Boot", "System", "Auto", "Manual", "Disabled")]
        [string]$StartMode
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    Write-Verbose "[$FunctionName] ServiceName: $ServiceName"
    Write-Verbose "[$FunctionName] DisplayName: $DisplayName"
    Write-Verbose "[$FunctionName] State: $State"
    Write-Verbose "[$FunctionName] StartMode: $StartMode"
    

    $Result = Get-WmiObject Win32_Service -ComputerName localhost | 
    Select-Object DisplayName, @{Name = 'LogonName'; Expression = { $_.StartName } }, ProcessId, State, StartMode

    if ($ServiceName) {
        $Result = $Result | Where-Object -Property Name -Like $ServiceName
        Write-Verbose "[$FunctionName] Filter for ServiceName $ServiceName applied"
    }

    if ($DisplayName) {
        $Result = $Result | Where-Object -Property DisplayName -Like $DisplayName
        Write-Verbose "[$FunctionName] Filter for DisplayName $DisplayName applied"
    }

    if (!$DisplayName -and !$ServiceName) {
        $Result = $Result | Where-Object -Property DisplayName -Like "*SQL*" 
        Write-Verbose "[$FunctionName] No ServiceName or DisplayName filter applied. Default filter for DisplayName with *SQL* applied" 
    }

    if ($State) {
        $Result = $Result | Where-Object -Property State -eq $State 
        Write-Verbose "[$FunctionName] Filter for State $State applied" 
    }

    if ($StartMode) { 
        $Result = $Result | Where-Object -Property StartMode -eq $StartMode 
        Write-Verbose "[$FunctionName] Filter for StartMode $StartMode applied" 
    }

    Write-Verbose "[$FunctionName] FUNCTION END"

    return (Format-Result $Result $NotFomated)

}