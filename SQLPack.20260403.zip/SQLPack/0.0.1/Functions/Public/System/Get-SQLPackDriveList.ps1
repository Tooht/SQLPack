﻿<#
.SYNOPSIS

.DESCRIPTION

.PARAMETER OutputFolderPath

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK
#>
function Get-SQLPackDriveList { 
    param (
        [Parameter(Mandatory = $false)]
        [switch] $NotFomated
    )
    $FunctionName = (Get-FunctionName)
    Write-Verbose "[$FunctionName] FUNCTION START"

    Write-Verbose "[$FunctionName] Parameters received: "
    Write-Verbose "[$FunctionName] NotFomated: $NotFomated"
    
    try {
        $Result = Get-CimInstance -ClassName Win32_LogicalDisk | 
        Where-Object { $_.DriveType -eq 3 } | 
        Select-Object DeviceID, VolumeName, @{Name = "SizeGB"; Expression = { [Math]::Floor(($_.Size / 1GB)) } }, @{Name = "FreeGB"; Expression = { [Math]::Floor(($_.FreeSpace / 1GB)) } }
    }
    catch {
        $Result = [SQLPackReturnError]::new("Error" + $FunctionName + "001", $_.Exception.Message, $null, $_.Exception)     
    }

    Write-Verbose "[$FunctionName] FUNCTION END"

    return (Format-Result $Result $NotFomated)
}