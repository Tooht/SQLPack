[CmdletBinding()]
#Get public and private function definition files.
$Public = @( Get-ChildItem -Path $PSScriptRoot\Functions\Public\*.ps1 -ErrorAction SilentlyContinue -Recurse)
$Private = @( Get-ChildItem -Path $PSScriptRoot\Functions\Private\*.ps1 -ErrorAction SilentlyContinue -Recurse )

#Dot source the files
Foreach ($import in @($Public + $Private)) {
    Try {
        . $import.fullname
        Write-Verbose  "Successfully imported function $($import.fullname)" 
    }
    Catch {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

# Here I might...
# Read in or create an initial config file and variable
# Export Public functions ($Public.BaseName) for WIP modules
# Set variables visible to the module and its functions only



Export-ModuleMember -Function $Public.Basename

"./private/Classes/*.ps1" 

write-verbose "Classes loaded successfully"

#Load Configurations
$ImportConfig = Import-SQLPackConfig
Write-Verbose "Config import result: $($ImportConfig.Result) - $($ImportConfig.Message)"



Write-Verbose "SQLPack module loaded successfully"  

